---
name: rxp-guide-builder
description: Write, check and package RestedXP (RXP) leveling guides for WoW Forever. Plans a fast quest route for a zone, race and class and exports it as an addon or for the RXP Visual Guide Builder.
---

# RXP guide builder

Makes RestedXP (RXP) leveling guides for WoW Forever: a `.lua` file that loads in the RestedXP addon, with the step-by-step text, waypoint arrows, quest tracking and side objectives. The bundled checker is the one the RXP Visual Guide Builder uses. It catches syntax mistakes, steps that misbehave in RXP (flashing past, missing arrows, vanishing side objectives) and quest-log order problems. It does **not** know required levels or quest chains. Those come from Wowhead and your route plan, so verify them yourself.

## Files

| Path | Use |
|---|---|
| `reference/rxp-syntax.md` | Guide syntax and how the addon runs it (step completion, arrows, side objectives). **Read before writing or editing a guide.** |
| `reference/routing.md` | How to plan an efficient route: level gates, chains, hubs, deathskips, XP table. |
| `reference/wowhead.md` | Where to get quest levels, chains, NPCs and coordinates on Wowhead (Forever). |
| `scripts/check_guide.js` | The checker. `node $SKILL/scripts/check_guide.js GUIDE.lua --race Undead --class Paladin [--list] [--window 27]` |
| `scripts/quest_info.js` | Quest givers, turn-ins (Forever zone coordinates) and objectives from RestedXP's data. `node $SKILL/scripts/quest_info.js 404` or `--zone "Tirisfal Glades" --horde` |
| `scripts/coords.js` | Convert RestedXP world coordinates to zone % and measure distances. |
| `scripts/wowhead.py` | Required level, chain, objectives, XP and NPC spawn points from Wowhead (Forever), when the sandbox has internet. |
| `scripts/make_addon.py` | Check and package guides as an addon zip players unzip into AddOns. |
| `templates/guide_template.lua` | Starting file. |
| `library/forever/` | RestedXP's own Forever guides (proven routes, ids, NPC names). See `library/INDEX.md`. |
| `examples/UD_Paladin_Tirisfal_1-12.lua` | A finished custom route (Undead Paladin, Tirisfal 1-12) that passes the checker. |

`$SKILL` above is this skill's folder. Scripts find their data next to themselves, so call them by full path from anywhere. Keep your own work (guides, zips, notes) in the working directory, **never inside the skill folder**. Node and Python 3 are enough; nothing to install.

## What to find out first

Ask only for what's missing, in one short message, then start:

- faction, race and class
- level range and zone(s), and where the character starts (fresh, or partway through)
- hardcore or not (no deathskips for hardcore)
- fastest route (skip low-value quests) or every quest
- guide name and group (default group: "My Guides")

If the person isn't around to answer, use: fastest route, softcore, group "My Guides", the race's starting zone, and say so at the top of your reply.

## Making a guide

1. **Read the references.** `reference/rxp-syntax.md` and `reference/routing.md`.
2. **Gather the quests.**
   - Open the RestedXP guide for the zone (`library/INDEX.md`, which also says which steps to ignore) to see the proven order, NPC names, quest ids and objective numbers.
   - `node $SKILL/scripts/quest_info.js --zone "Zone Name" --horde` (or `--alliance`) for givers and turn-ins with Forever coordinates.
   - For each quest you plan to use, confirm on Wowhead: required level, chain (what unlocks it), objectives, XP, class/race limits (`python3 $SKILL/scripts/wowhead.py quest ID ...`, or `reference/wowhead.md`). The checker can't do this for you.
   - Keep a table: id, name, required level, giver, turn-in, objectives and where, XP, prerequisite. Never invent ids or coordinates; if you can't confirm one, say so.
3. **Plan the route** (`reference/routing.md`): hubs, areas, trips, and the character's level at each hub. Every pickup must be at or below the level the character has by then. Add grind steps (`.xp N`) where the level falls short. In a live conversation, show the plan as a short list of trips before writing a long guide.
4. **Write the guide** from `templates/guide_template.lua`:
   - `#forever`, `#group`, `#name`, a `<<` filter for who it's for.
   - `#next` only if you know the next guide's exact `#name`. RestedXP's next guide assumes its own earlier route was followed (quests already in the log). So either pick those quests up before the hand-over and say so, or leave `#next` out.
   - Zone % coordinates (`.goto Tirisfal Glades,52.50,54.50`).
   - Colour codes for NPCs, enemies, loot and objects; `.target`/`.mob` for target buttons.
   - Side objectives with `#completewith`, trackers with `#sticky`, guarded turn-ins, level-gated pickups.
5. **Check it.**
   - `node $SKILL/scripts/check_guide.js GUIDE.lua --race R --class C`.
   - Fix every ERROR. Read every WARNING and either fix it or keep it on purpose (a deliberate backup turn-in, for example). Notes about quest ids or objective numbers RestedXP never uses mean: check that id on Wowhead.
   - Then check by hand what the checker can't: walk the route and confirm the character meets each quest's required level and has done its prerequisite before every `.accept`.
   - `--list` shows each step with the running distance: a big jump means a detour.
   - `--window N` prints what the player sees in the RXP window and arrow at step N. Use it on steps with side objectives.
6. **Deliver** (below).

## Editing an existing guide

Read the whole guide first and keep its style. Change only what's asked. Refer to steps by number: step N = the Nth step that applies to the character, the same numbering the checker and the RXP Visual Guide Builder use. Run the checker again and list what changed by step number.

## Delivering

- Save the guide with the `RXPGuides.RegisterGuide([[ ... ]])` wrapper under a file name without spaces (`1-6_Valley_of_Trials_Orc_Warrior.lua`) and give the file to the person.
- To make it installable directly: `python3 $SKILL/scripts/make_addon.py GUIDE.lua [MORE.lua] --race R --class C [--name RXPGuides_Tirisfal] [--out PATH.zip]`.
  - It runs the checker first and stops on errors (`--force` overrides).
  - By default the zip goes next to the first guide, and the addon folder is `RXPGuides_` plus the file name.
  - Give each pack its own `--name`. A zip with the same folder name as an addon the player already has replaces it, so the builder's `RXPGuides_MyGuides` is refused without `--replace`.
- Install: unzip into `World of Warcraft\_classic_beta_\Interface\AddOns`, with RestedXP installed. **The first time, restart WoW completely** (new addon folders are only found at startup; `/reload` isn't enough). After later edits to the `.lua`, `/reload` is enough. The guide appears in the RXP guide menu under its `#group`.
- To view or edit it on the map: RXP Visual Guide Builder, **File → Import**.
- RXP's in-game Import box only accepts RestedXP's own encrypted guide strings, so custom guides always load as an addon.
- In the reply, summarise:
  - the route as a list of trips,
  - quests you skipped and why,
  - level assumptions and grind steps,
  - checker warnings you kept on purpose.

## Rules that break guides

Full detail in `reference/rxp-syntax.md`. The ones that cause most problems:

The checker reports 1, 2, 6 and 9 as errors.

1. Every step needs something that can complete. A step with only a `.goto` and no radius flashes past.
2. No `>>text` on a goto line without a radius: the arrow disappears. Put the text on its own line.
3. In a step with several NPCs, write each `.goto` right after the line it belongs to.
4. Don't `.accept` above the player's level in that step. Grind first (`.xp N`) or guard the step with `.xp <N,1`. (Not checked automatically.)
5. `--` starts a comment, even in the middle of guide text.
6. Side objectives (`#completewith`, `#sticky`) need a completable element (`.complete`, `.collect`, `.deathskip`, `+checkbox`), or they vanish immediately.
7. Deathskips go under `#softcore`. Resurrection sickness starts after level 10. Only deathskip where you know which graveyard the player lands at (`reference/routing.md`).
8. Never invent quest ids, NPC names or coordinates. Use the library, `quest_info.js` or Wowhead, and say so when something couldn't be confirmed. RestedXP's guides also carry Season of Discovery steps (`#season 2`, quest ids 76000-77999); those quests don't exist in WoW Forever.
9. `#completewith Label` / `#requires Label` must name a `#label` in the same guide, and a `#completewith` target must come later than the side objective.

## Credits

The guide library and quest data come from RestedXP's guides (CC BY-NC-SA 4.0). Map coordinates and zone data come from WoW Forever's map files. Guides made with this skill are free fan content: credit RestedXP when you share them, and don't sell them.
