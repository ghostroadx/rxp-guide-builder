#!/usr/bin/env python3
"""Package one or more RXP guide .lua files as a WoW addon zip that players unzip into Interface/AddOns.

    python3 make_addon.py GUIDE.lua [MORE.lua ...] [--name RXPGuides_Tirisfal] [--title "Tirisfal"]
                          [--author NAME] [--out PATH.zip] [--race Undead --class Paladin] [--force]

The zip holds one folder (the addon name) with a .toc that depends on RXPGuides and every guide .lua.
Defaults: --name is RXPGuides_ plus the first guide's file name, --title is its #name, and the zip is
written next to the first guide. Use a name of its own for each pack: unzipping over an existing folder
with the same name (for example the RXP Visual Guide Builder's RXPGuides_MyGuides) replaces that addon,
so that name is refused unless you add --replace.
Every guide is run through check_guide.js first (with --race/--class if given); packaging stops when it
reports errors, unless you add --force. Guide file names inside the zip are cleaned to letters, digits, _ and -.
Lines are written with Windows line endings, like the RXP Visual Guide Builder's export.
Interface 16001 is WoW Forever and 11509 is Classic Era (the same values the builder uses).
"""
import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))


def safe_file(name):
    stem, ext = os.path.splitext(name)
    stem = re.sub(r'[^A-Za-z0-9_\-]+', '_', stem).strip('_') or 'Guide'
    return stem + (ext if ext.lower() == '.lua' else '.lua')


def run_checker(path, race, cls):
    node = shutil.which('node')
    if not node:
        print('(node not found: skipped the checker)')
        return 0
    cmd = [node, os.path.join(HERE, 'check_guide.js'), path, '--json']
    if race:
        cmd += ['--race', race]
    if cls:
        cmd += ['--class', cls]
    p = subprocess.run(cmd, capture_output=True, text=True)
    if p.returncode == 2:
        sys.exit(p.stderr.strip() or p.stdout.strip())
    try:
        results = json.loads(p.stdout)
    except ValueError:
        print('(could not read the checker output: skipped)')
        return 0
    n = 0
    for r in results:
        for e in r['errors']:
            n += 1
            print('  ERROR %s, step %s: %s' % (r['name'], e['step'], e['msg']))
    return n

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('guides', nargs='+', help='guide .lua files (each with RXPGuides.RegisterGuide blocks)')
    ap.add_argument('--name', default=None, help='addon folder name (letters, digits, _ and -)')
    ap.add_argument('--title', default=None)
    ap.add_argument('--author', default='')
    ap.add_argument('--version', default='1.0')
    ap.add_argument('--interface', default='16001, 11509')
    ap.add_argument('--out', default=None)
    ap.add_argument('--race', default=None, help='check the guides as this race (passed to check_guide.js)')
    ap.add_argument('--class', dest='cls', default=None, help='check the guides as this class')
    ap.add_argument('--force', action='store_true', help='package even if the checker reports errors')
    ap.add_argument('--replace', action='store_true', help='allow the name RXPGuides_MyGuides (replaces the builder addon)')
    a = ap.parse_args()

    first = a.guides[0]
    if a.name is None:
        stem = re.sub(r'[^A-Za-z0-9_\-]+', '_', os.path.splitext(os.path.basename(first))[0]).strip('_') or 'Guides'
        a.name = stem if stem.startswith('RXPGuides_') else 'RXPGuides_' + stem
    if not re.fullmatch(r'[A-Za-z0-9_\-]+', a.name):
        sys.exit('Addon name may only use letters, digits, _ and -')
    if a.name == 'RXPGuides':
        sys.exit('RXPGuides is the RestedXP addon itself; pick another name.')
    if a.name.lower() == 'rxpguides_myguides' and not a.replace:
        sys.exit('RXPGuides_MyGuides is the RXP Visual Guide Builder\'s addon folder: unzipping over it would remove the guides '
                 'already in it. Pick another --name, or add --replace if replacing it is what you want.')
    files = []
    for g in a.guides:
        text = open(g, encoding='utf-8').read()
        if 'RegisterGuide' not in text:
            sys.exit(g + ': no RXPGuides.RegisterGuide([[ ... ]]) block. Wrap the guide first (see templates/guide_template.lua).')
        if not re.search(r'^\s*#name\s+\S', text, re.M) or not re.search(r'^\s*#group\s+\S', text, re.M):
            sys.exit(g + ': every guide needs a #name and a #group line or RXP ignores it.')
        files.append((safe_file(os.path.basename(g)), text))
    names = [n for n, _ in files]
    if len(set(names)) != len(names):
        sys.exit('Two guides end up with the same file name (%s). Rename one.' % ', '.join(names))
    errors = sum(run_checker(g, a.race, a.cls) for g in a.guides)
    if errors and not a.force:
        sys.exit('Not packaged: the checker found %d error(s) above. Fix them, or add --force to package anyway.' % errors)
    if a.title is None:
        m = re.search(r'^\s*#name\s+(.+?)\s*$', files[0][1], re.M)
        a.title = m.group(1) if m else a.name

    toc = [
        '## Interface: ' + a.interface,
        '## Title: RXPGuides - ' + a.title,
        '## Notes: RXP guides made with the RXP guide builder skill',
    ]
    if a.author:
        toc.append('## Author: ' + a.author)
    toc += ['## Version: ' + a.version, '## Dependencies: RXPGuides', '']
    toc += [name for name, _ in files]

    out = a.out or os.path.join(os.path.dirname(os.path.abspath(first)), a.name + '.zip')
    crlf = lambda s: s.replace('\r\n', '\n').replace('\n', '\r\n')
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr(a.name + '/' + a.name + '.toc', crlf('\n'.join(toc) + '\n'))
        for name, text in files:
            z.writestr(a.name + '/' + name, crlf(text))
    print('Wrote ' + out + ': folder ' + a.name + '/ with ' + str(len(files)) + ' guide file(s).')
    print('Players unzip it into World of Warcraft\\_classic_beta_\\Interface\\AddOns (RestedXP must be installed).')
    print('First install: restart WoW completely (a new addon folder is only found at startup). After editing the .lua later, /reload is enough.')

if __name__ == '__main__':
    main()
