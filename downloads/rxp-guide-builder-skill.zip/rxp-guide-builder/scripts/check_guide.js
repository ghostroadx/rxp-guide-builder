#!/usr/bin/env node
/*
 * Check an RXP guide the same way the RXP Visual Guide Builder does.
 *
 *   node check_guide.js GUIDE.lua [--race Undead] [--class Paladin] [--faction Horde] [--hardcore]
 *                                 [--list] [--window N[,N...]] [--json]
 *
 * GUIDE can be a .lua file with RXPGuides.RegisterGuide([[ ... ]]) blocks or the bare guide text.
 * --race / --class   check the guide as that character (steps and lines filtered with << are skipped
 *                    when they don't apply). Faction comes from the race; Skyborne can be either, so add
 *                    --faction for them.
 * --hardcore         check as a hardcore character (#hardcore steps instead of #softcore ones).
 * --list             print every step with its number, what it does, where, and the running distance.
 * --window N         print what the in-game RXP window and arrow show when the guide is on step N.
 *                    It assumes the player did every earlier step in order, including guarded ones
 *                    (.isQuestComplete turn-ins), so treat it as the "everything went to plan" view.
 * --json             machine-readable output.
 * Exit code 1 when there are errors.
 *
 * What it checks: syntax, zones and coordinates, steps that can't complete, arrows hidden by text,
 * empty side objectives, the quest log (accept/turn-in order, duplicates, size), the << filters,
 * and quest ids / objective numbers against RestedXP's data.
 * What it does NOT check: required levels, quest chains (prerequisites), class/race-only quests and XP.
 * Get those from Wowhead and plan around them (reference/routing.md).
 */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ctx = { window: {} };
vm.createContext(ctx);
for (const f of ['zones.js', 'meta.js', 'quests.js']) vm.runInContext(fs.readFileSync(path.join(__dirname, 'data', f), 'utf8'), ctx);
const RXP = require('./lib/rxp.js');
const GEO = require('./lib/geo.js');
const MODEL = require('./lib/model.js');
GEO.init(ctx.window.RXPB_ZONES, ctx.window.WOWMAP_META);
const QDB = ctx.window.RXPB_QUESTS;

const RACE_ALIASES = { undead: 'Scourge', scourge: 'Scourge', forsaken: 'Scourge', human: 'Human', dwarf: 'Dwarf', nightelf: 'NightElf', 'night elf': 'NightElf',
  'night-elf': 'NightElf', gnome: 'Gnome', orc: 'Orc', tauren: 'Tauren', troll: 'Troll', skyborne: 'Skyborne' };
const usageFail = msg => { console.error(msg); process.exit(2); };

function parseArgs(argv) {
  const o = { file: null, race: null, cls: null, faction: null, hardcore: false, list: false, window: [], json: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--race') o.race = argv[++i];
    else if (a === '--class') o.cls = argv[++i];
    else if (a === '--faction') o.faction = argv[++i];
    else if (a === '--hardcore') o.hardcore = true;
    else if (a === '--list') o.list = true;
    else if (a === '--json') o.json = true;
    else if (a === '--window') o.window = String(argv[++i]).split(',').map(Number).filter(n => n > 0);
    else if (a === '-h' || a === '--help') { console.log(fs.readFileSync(__filename, 'utf8').split('*/')[0]); process.exit(0); }
    else if (a.startsWith('--')) usageFail('Unknown option ' + a + ' (see --help)');
    else o.file = a;
  }
  if (!o.file) { console.error('Usage: node check_guide.js GUIDE.lua [--race Scourge] [--class PALADIN] [--list] [--window N]'); process.exit(2); }
  return o;
}

function profileOf(o) {
  const race = o.race ? RACE_ALIASES[o.race.toLowerCase()] : null;
  if (o.race && !race) usageFail('Unknown race "' + o.race + '". Use one of: Human, Dwarf, NightElf, Gnome, Orc, Undead, Tauren, Troll, Skyborne');
  const cls = o.cls ? o.cls.toUpperCase() : null;
  if (cls && !RXP.CLASSES.includes(cls)) usageFail('Unknown class "' + o.cls + '". Use one of: ' + RXP.CLASSES.map(c => c[0] + c.slice(1).toLowerCase()).join(', '));
  let faction = race ? RXP.RACES[race] || null : null;
  if (o.faction) {
    faction = { horde: 'Horde', alliance: 'Alliance' }[o.faction.toLowerCase()];
    if (!faction) usageFail('--faction must be Horde or Alliance');
  }
  return { faction, race, class: cls, hardcore: o.hardcore, game: 'FOREVER', xprate: 1 };
}

const SERIOUS = [/flashes past/, /hides the arrow/, /side objective has nothing/, /no step in this guide has #label/];
const qn = id => (QDB[id] && QDB[id][0]) || ('quest ' + id);
const fmtYd = yd => yd >= 10000 ? (yd / 1000).toFixed(1) + 'k yd' : Math.round(yd) + ' yd';
const fmtTime = s => { const m = Math.floor(s / 60); return m >= 60 ? Math.floor(m / 60) + 'h ' + (m % 60) + 'm' : m + 'm ' + Math.round(s % 60) + 's'; };

function where(a) {
  // the step's real destination: an arrow/objective goto, before hidden path waypoints and pins
  const g = a.gotos.find(x => x.pos && (x.kind === 'arrow' || x.kind === 'waypoint' || x.kind === 'closest')) ||
    a.gotos.find(x => x.pos && x.kind !== 'pin') || a.gotos.find(x => x.pos);
  if (!g) return '';
  const p = g.pos;
  let x = p.x, y = p.y, zid = p.zone;
  if (x === undefined) { const zz = GEO.zonesAt(p.wx, p.wy, p.inst, 'forever')[0]; if (zz) { const z = GEO.worldToZone(zz, p.wx, p.wy, 'forever'); x = z.x; y = z.y; zid = zz; } }
  return GEO.zoneName(zid) + (x !== undefined ? ' ' + x.toFixed(1) + ',' + y.toFixed(1) : '');
}

// ---- in-game window text (mirrors the builder's In-game view)
function objectiveParts(e) {
  const q = QDB[e.q];
  const src = String(e.comment || (q && q[3] && q[3][e.o]) || '').trim();
  let name = src, count = 1, m = name.match(/^\|?\s*(\d+)\s*\/\s*(\d+)\s+(.*)$/);
  if (m) { count = +m[2]; name = m[3]; }
  m = name.match(/^(.*?)\s*\(x?(\d+)\)\s*$/);
  if (m) { name = m[1]; count = +m[2]; }
  let kill = /^Kill\s+/i.test(name);
  name = name.replace(/^Kill\s+/i, '').replace(/^Collect\s+/i, '');
  if (!name) name = qn(e.q) + ' objective ' + (e.o || '');
  if (kill && !/slain$/i.test(name)) name += ' slain';
  return { name, count };
}
function lineText(e) {
  if (e.text) return e.text;
  switch (e.tag) {
    case 'accept': return 'Accept ' + qn(e.q);
    case 'turnin': return 'Turn in ' + qn(e.q);
    case 'complete': { const o = objectiveParts(e); return o.name + ': ' + (e.done ? o.count : 0) + '/' + o.count; }
    case 'collect': { const c = String(e.comment || '').replace(/\s*\(\d+\)\s*$/, '').trim() || ('item ' + e.item); return c + ': ' + (e.done ? e.n : 0) + '/' + e.n; }
    case 'xp': return 'Grind to level ' + e.level;
    case 'deathskip': return 'Die and respawn at the Spirit Healer';
    case 'hs': return 'Hearth';
    case 'home': return 'Set your Hearthstone here';
    case 'vendor': return 'Sell junk/resupply';
    case 'trainer': return 'Train skills';
    case 'goto': return 'Go to ' + (+e.args[1]).toFixed(1) + ',' + (+e.args[2]).toFixed(1);
  }
  return null;
}
const COND = {
  isOnQuest: c => 'only if on ' + qn(c.q), isNotOnQuest: c => 'only if not on ' + qn(c.q),
  isQuestTurnedIn: c => 'only if ' + qn(c.q) + ' is turned in', isQuestAvailable: c => 'skipped if ' + qn(c.q) + ' is turned in',
  isQuestComplete: c => 'only if ' + qn(c.q) + ' is complete', isQuestNotComplete: c => 'only if ' + qn(c.q) + ' is not complete',
  xp: c => c.reverse ? 'skipped below level ' + c.level : 'skipped from level ' + c.level, maxlevel: () => 'only below a level cap'
};
function windowText(g, an, prof, number) {
  const idx = an.steps.findIndex(a => a.number === number);
  if (idx < 0) return 'Step ' + number + ' does not exist for this character.';
  const sim = MODEL.simulateWindow(g, an, prof, idx);
  const out = [];
  if (sim.cur !== idx) out.push('(step ' + number + ' is a side objective; the guide sits on step ' + an.steps[sim.cur].number + ')');
  if (sim.arrow) {
    let d = '';
    if (sim.travel) d = 'after ' + ({ death: 'deathskip', hs: 'hearth', fly: 'flight', ship: 'boat' }[sim.travel] || sim.travel);
    else if (sim.from && sim.from.inst === sim.arrow.pos.inst) d = fmtYd(GEO.dist(sim.from, sim.arrow.pos));
    out.push('Arrow: ' + (d || '-') + ' to step ' + an.steps[sim.arrow.si].number + ' line ' + (sim.arrow.idx + 1));
  } else out.push('Arrow: none');
  const targets = new Set();
  for (const r of sim.rows) {
    out.push('[' + (r.role === 'current' ? 'current' : 'side') + '] step ' + r.number + (r.completewith ? '  (#completewith ' + r.completewith + ')' : r.sticky ? '  (#sticky)' : ''));
    for (const e of r.els) {
      if (e.cond) continue;
      if (e.target) { e.names.forEach(n => targets.add((e.target === 'enemy' ? 'enemy: ' : '') + n)); continue; }
      if (e.goto && e.textOnly) { if (e.text) out.push('      ' + RXP.stripCodes(e.text)); continue; }
      const t = lineText(e); if (t === null) continue;
      const box = e.objective && !e.noCheck ? (e.done ? '[x] ' : '[ ] ') : '    ';
      out.push('  ' + box + RXP.stripCodes(t));
    }
    if (r.skipped) out.push('  ! RXP skips this step: ' + r.conds.filter(c => c.ok === false).map(c => (COND[c.tag] || (() => c.tag))(c)).join('; '));
    else if (r.alreadyDone) out.push('  ! RXP skips this step: everything in it is already done');
    else if (r.conds.length) out.push('  (' + r.conds.map(c => (COND[c.tag] || (() => c.tag))(c)).join('; ') + ')');
  }
  if (targets.size) out.push('Targets: ' + [...targets].join(', '));
  if (sim.upcoming.length) out.push('Next: ' + sim.upcoming.map(i => an.steps[i].number + ' ' + MODEL.stepSummary(g.steps[i], an.steps[i], QDB)).join(' | '));
  return out.join('\n');
}

function checkGuide(g, prof, o) {
  const an = MODEL.analyzeGuide(g, prof);
  const chk = MODEL.check(g, an, prof, QDB);
  const num = si => an.steps[si] && an.steps[si].number ? an.steps[si].number : '(not for this character) #' + (si + 1);
  const issues = chk.issues.map(i => ({ sev: i.sev, step: num(i.step), line: i.line !== undefined ? i.line + 1 : null,
    text: i.line !== undefined ? g.steps[i.step].lines[i.line] : null, msg: i.msg }));
  const name = RXP.headerGet(g.headerLines, 'name') || '(no #name)';
  // In a guide written with this skill these always mean the step misbehaves in game, so they are errors here.
  for (const i of issues) if (i.sev === 'warn' && SERIOUS.some(re => re.test(i.msg))) i.sev = 'error';
  // Quest ids and objective numbers RestedXP never uses: often a typo or a quest that isn't in WoW Forever.
  an.steps.forEach((a, si) => {
    if (!a.applies) return;
    for (const q of a.accepts.concat(a.turnins, a.completes)) {
      const e = QDB[q.id];
      if (+q.id >= 76000 && +q.id < 78000) issues.push({ sev: 'warn', step: num(si), line: q.idx + 1, text: g.steps[si].lines[q.idx], msg: qn(q.id) + ' (' + q.id + ') is a Season of Discovery quest (RestedXP marks those #season 2). It does not exist in WoW Forever' });
      else if (!e) issues.push({ sev: 'info', step: num(si), line: q.idx + 1, text: g.steps[si].lines[q.idx], msg: 'Quest ' + q.id + ' is not in RestedXP\'s quest data. Check the id on Wowhead (Forever) before shipping' });
      else if (q.obj !== undefined && e[3] && Object.keys(e[3]).length && !(String(q.obj) in e[3]))
        issues.push({ sev: 'info', step: num(si), line: q.idx + 1, text: g.steps[si].lines[q.idx], msg: 'Objective ' + q.obj + ' of ' + qn(q.id) + ' is not one RestedXP uses (known: ' + Object.entries(e[3]).map(([k, v]) => k + ' = ' + v).join(', ') + ')' });
    }
  });
  const res = {
    name, loads: true, steps: g.steps.length, applies: an.steps.filter(a => a.applies).length,
    errors: issues.filter(i => i.sev === 'error'), warnings: issues.filter(i => i.sev === 'warn'), notes: issues.filter(i => i.sev === 'info'),
    openQuests: chk.openQuests.map(id => ({ id, name: qn(id) })), maxQuestLog: chk.maxLog, maxQuestLogStep: chk.maxAt >= 0 ? num(chk.maxAt) : null,
    walkYards: Math.round(an.totalWalk)
  };
  const hf = RXP.headerFilter(g.headerLines);
  if (hf && (prof.race || prof.class) && !RXP.applies(hf, prof)) {
    res.loads = false; res.applies = 0;
    res.errors.unshift({ sev: 'error', step: 'header', line: null, text: '<< ' + hf, msg: 'This guide does not load for this character (guide filter << ' + hf + '). Fix the << line or check with the right --race/--class' });
  }
  const header = ['name', 'group'].filter(t => !RXP.headerGet(g.headerLines, t));
  if (header.length) res.errors.unshift({ sev: 'error', step: 'header', line: null, text: null, msg: 'Missing #' + header.join(' and #') + ' (RXP needs both to load the guide)' });
  if (!RXP.headerHas(g.headerLines, 'forever')) res.notes.unshift({ sev: 'info', step: 'header', line: null, text: null, msg: 'No #forever tag: zone coordinates are read as Classic Era maps (they differ in Mulgore, Redridge, Eastern Plaguelands and Stormwind)' });
  if (o.list) res.list = an.steps.map((a, si) => a.applies ? { n: a.number, icon: MODEL.stepIcon(a), what: MODEL.stepSummary(g.steps[si], a, QDB), where: where(a), walk: Math.round(a.walk) } : null).filter(Boolean);
  if (o.window.length) res.windows = o.window.map(n => ({ step: n, text: windowText(g, an, prof, n) }));
  return res;
}

function printText(r, speed) {
  const L = [];
  L.push('Guide: ' + r.name + ' — ' + (r.loads ? r.applies + ' of ' + r.steps + ' steps apply to this character' : 'DOES NOT LOAD for this character (0 of ' + r.steps + ' steps)'));
  const block = (title, arr) => {
    L.push('', title + ' (' + arr.length + ')');
    for (const i of arr) {
      L.push('  Step ' + i.step + (i.line ? ' line ' + i.line : '') + ': ' + i.msg);
      if (i.text) L.push('      > ' + i.text);
    }
  };
  block('ERRORS', r.errors);
  block('WARNINGS', r.warnings);
  if (r.notes.length) block('Notes', r.notes);
  L.push('', 'Quest log: at most ' + r.maxQuestLog + ' quests' + (r.maxQuestLogStep !== null ? ' (step ' + r.maxQuestLogStep + ')' : '') + '. Still open at the end: ' +
    (r.openQuests.length ? r.openQuests.map(q => q.name + ' (' + q.id + ')').join(', ') : 'none'));
  L.push('Running: ' + fmtYd(r.walkYards) + ' ≈ ' + fmtTime(r.walkYards / speed) + ' at ' + speed + ' yd/s between steps (straight lines; time inside #loop circuits, hearths, deathskips and flights not counted)');
  if (r.list) {
    L.push('', 'STEPS');
    let total = 0;
    for (const s of r.list) { total += s.walk; L.push(String(s.n).padStart(4) + '  ' + ('[' + s.icon + ']').padEnd(11) + s.what.slice(0, 70).padEnd(72) + (s.where || '').padEnd(28) + (s.walk ? '+' + fmtYd(s.walk) : '')); }
  }
  for (const w of r.windows || []) L.push('', 'IN-GAME VIEW AT STEP ' + w.step, w.text);
  return L.join('\n');
}

const o = parseArgs(process.argv.slice(2));
const src = fs.readFileSync(o.file, 'utf8');
const blocks = RXP.looksLikeBareGuide(src) ? [{ text: src }] : RXP.extractGuidesFromLua(src);
if (!blocks.length) { console.error('No guide found. Expected RXPGuides.RegisterGuide([[ ... ]]) or bare guide text starting with header tags and "step" lines.'); process.exit(2); }
const prof = profileOf(o);
const results = blocks.map(b => checkGuide(RXP.parseGuideText(b.text, b.group), prof, o));
if (o.json) console.log(JSON.stringify(results, null, 1));
else console.log(results.map(r => printText(r, 7)).join('\n\n' + '='.repeat(60) + '\n\n'));
process.exitCode = results.some(r => r.errors.length) ? 1 : 0;
