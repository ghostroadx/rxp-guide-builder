#!/usr/bin/env node
/*
 * Look up quests in the bundled quest data (mined from the RestedXP guides).
 *
 *   node quest_info.js 404 99141            by quest id
 *   node quest_info.js "gordo"              by name (case-insensitive, partial match)
 *   node quest_info.js --zone "Tirisfal Glades" [--horde|--alliance] [--all]   every quest given or turned in there
 *
 * --zone takes a zone (map) name such as Durotar or Tirisfal Glades. Subzones (Valley of Trials, Deathknell)
 * are part of their zone. Season of Discovery quests that RestedXP's guides also carry are left out of
 * --zone lists (add --all to see them) and marked when looked up directly: they don't exist in WoW Forever.
 *
 * For each quest: name, faction, the level range of the RestedXP guides it appears in, where it is
 * picked up and turned in (NPC name and WoW Forever zone coordinates ready for .goto), and objective names.
 * This data does NOT have required levels, chains or XP: get those from Wowhead (see reference/wowhead.md).
 * Some givers/turn-ins have no NPC name here; the RestedXP guide in library/forever/ or Wowhead has it.
 */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const ctx = { window: {} };
vm.createContext(ctx);
for (const f of ['zones.js', 'meta.js', 'quests.js']) vm.runInContext(fs.readFileSync(path.join(__dirname, 'data', f), 'utf8'), ctx);
const GEO = require('./lib/geo.js');
GEO.init(ctx.window.RXPB_ZONES, ctx.window.WOWMAP_META);
const Q = ctx.window.RXPB_QUESTS;

function zonePos(loc) {
  const [wx, wy, inst, , npc] = loc;
  const zid = locZone(loc);
  if (!zid) return { text: 'world ' + wx + ',' + wy + ' (continent ' + inst + ')', npc };
  const z = GEO.worldToZone(zid, wx, wy, 'forever');
  return { zone: GEO.zoneName(zid), x: z.x, y: z.y, npc, text: GEO.zoneName(zid) + ',' + z.x.toFixed(2) + ',' + z.y.toFixed(2) };
}
// The zone the RestedXP guide wrote the point in (zone frames overlap: The Barrens' frame covers southern Mulgore).
// Falls back to the first zone map that contains the point.
function locZone(loc) {
  const [wx, wy, inst, , , mapId] = loc;
  const z = mapId && GEO.zone(mapId);
  if (z && z.type === 3 && GEO.worldToZone(mapId, wx, wy, 'forever')) return mapId;
  return GEO.zonesAt(wx, wy, inst, 'forever')[0];
}
const FACTION = { 1: 'Alliance', 2: 'Horde', 3: 'both' };
// RestedXP's Forever guides include Season of Discovery steps (#season 2); those quests use ids 76000-77999.
const isSoD = id => +id >= 76000 && +id < 78000;
// '|6/6 Dry Branch' / 'Kill Mindless Zombie (x8)' -> 'Dry Branch (6)' / 'Mindless Zombie (8)'
function objName(v) {
  let t = String(v || '').trim(), n = null, m = t.match(/^\|?\s*\d+\s*\/\s*(\d+)\s+(.*)$/);
  if (m) { n = m[1]; t = m[2]; }
  m = t.match(/^(.*?)\s*\(x?(\d+)\)\s*$/);
  if (m) { t = m[1]; n = m[2]; }
  t = t.replace(/^(Kill|Collect)\s+/i, '');
  return n ? t + ' (' + n + ')' : t;
}

function show(id) {
  const e = Q[id];
  if (!e) return 'Quest ' + id + ': not in the bundled data (look it up on Wowhead).';
  const [name, acc, tin, obj, fm, lmin, lmax] = e;
  const L = [id + '  ' + (name || '(no name)') + '   [' + (FACTION[fm] || '?') + (lmin ? ', in guides for levels ' + lmin + '-' + lmax : '') + ']' +
    (isSoD(id) ? '   ** Season of Discovery only: not in WoW Forever **' : '')];
  const fmt = (label, list) => {
    if (!list.length) return L.push('  ' + label + ': unknown');
    list.forEach((loc, i) => { const p = zonePos(loc); L.push('  ' + (i ? ' '.repeat(label.length) : label) + ': ' + (p.npc ? p.npc + ' @ ' : '') + '.goto ' + p.text); });
  };
  fmt('Accept ', acc);
  fmt('Turn in', tin);
  const objs = Object.entries(obj || {});
  if (objs.length) L.push('  Objectives: ' + objs.map(([k, v]) => k + ' = ' + objName(v)).join(' | '));
  return L.join('\n');
}

const args = process.argv.slice(2);
if (!args.length || args.includes('--help') || args.includes('-h')) { console.log(fs.readFileSync(__filename, 'utf8').split('*/')[0]); process.exit(0); }
const zi = args.indexOf('--zone');
if (zi >= 0) {
  const zname = args[zi + 1];
  const zid = GEO.zoneIdByName(zname);
  if (!zid) { console.error('Unknown zone "' + zname + '". Use the zone (map) name, e.g. Durotar, Tirisfal Glades, Elwynn Forest; subzones like Valley of Trials belong to their zone.'); process.exit(2); }
  const want = args.includes('--horde') ? 2 : args.includes('--alliance') ? 1 : 0;
  const ids = Object.keys(Q).filter(id => {
    const e = Q[id];
    if (want && !(e[4] & want)) return false;
    if (isSoD(id) && !args.includes('--all')) return false;
    return e[1].concat(e[2]).some(loc => locZone(loc) === zid);
  }).sort((a, b) => (Q[a][5] - Q[b][5]) || (a - b));
  console.log(ids.length + ' quests in ' + GEO.zoneName(zid) + ':\n');
  console.log(ids.map(show).join('\n'));
  process.exit(0);
}
const out = [];
for (const a of args) {
  if (/^\d+$/.test(a)) { out.push(show(a)); continue; }
  const q = a.toLowerCase();
  const hits = Object.keys(Q).filter(id => (Q[id][0] || '').toLowerCase().includes(q)).slice(0, 15);
  out.push(hits.length ? hits.map(show).join('\n') : 'No quest named like "' + a + '".');
}
console.log(out.join('\n\n'));
