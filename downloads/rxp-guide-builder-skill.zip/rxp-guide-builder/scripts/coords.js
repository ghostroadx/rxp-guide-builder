#!/usr/bin/env node
/*
 * Convert RXP coordinates between world format and WoW Forever zone percent.
 *
 *   node coords.js "1420/0,1184.71,2205.63"          world (RestedXP's format) -> zone %   (.goto Tirisfal Glades,40.91,54.17)
 *   node coords.js "Tirisfal Glades,40.91,54.17"     zone % -> world, and the distance from the previous argument
 *   node coords.js A B C ...                          several points: prints each, plus the walking distance between them
 *   node coords.js --convert GUIDE.lua > OUT.lua      rewrite every world-format .goto in a guide to zone % (keeps radius/flags)
 *
 * RestedXP's Forever guides write ".goto 1420/0,<y>,<x>" in world units. Your guides can use either;
 * zone % (".goto Zone Name,x,y") is easier to read and is what Wowhead and in-game coordinate addons show.
 */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const ctx = { window: {} };
vm.createContext(ctx);
for (const f of ['zones.js', 'meta.js']) vm.runInContext(fs.readFileSync(path.join(__dirname, 'data', f), 'utf8'), ctx);
const GEO = require('./lib/geo.js');
GEO.init(ctx.window.RXPB_ZONES, ctx.window.WOWMAP_META);

function parse(s) {
  const parts = String(s).split(',').map(t => t.trim());
  if (parts.length < 3) return null;
  const pos = GEO.resolvePoint(parts[0], parts[1], parts[2], 'forever');
  if (!pos || pos.unknownZone) return null;
  let zid = pos.zone, x = pos.x, y = pos.y;
  if (x === undefined) {
    zid = GEO.zone(zid) ? zid : GEO.zonesAt(pos.wx, pos.wy, pos.inst, 'forever')[0];
    const z = zid && GEO.worldToZone(zid, pos.wx, pos.wy, 'forever');
    if (z) { x = z.x; y = z.y; }
  }
  return { pos, zid, x, y, rest: parts.slice(3) };
}
function zoneText(p) { return GEO.zoneName(p.zid) + ',' + p.x.toFixed(2) + ',' + p.y.toFixed(2); }

const args = process.argv.slice(2);
if (!args.length) { console.log(fs.readFileSync(__filename, 'utf8').split('*/')[0]); process.exit(0); }
if (args[0] === '--convert') {
  const src = fs.readFileSync(args[1], 'utf8');
  let n = 0;
  const out = src.replace(/(\.(?:goto|waypoint|groundgoto|flygoto)\s+)(\d+\/\d+\s*,\s*-?[\d.]+\s*,\s*-?[\d.]+)((?:\s*,[^\s>]*)*)/g, (m, cmd, pt, tail) => {
    const p = parse(pt);
    if (!p || p.x === undefined) return m;
    n++;
    return cmd + zoneText(p) + tail;
  });
  process.stdout.write(out);
  process.stderr.write('Converted ' + n + ' coordinates.\n');
  process.exit(0);
}
let prev = null;
for (const a of args) {
  const p = parse(a);
  if (!p) { console.log(a + '  ->  could not read (expected "Zone Name,x,y" or "1420/0,y,x")'); continue; }
  let line = a + '\n    zone:  .goto ' + (p.x !== undefined ? zoneText(p) : '?') + '\n    world: .goto ' + p.zid + '/' + p.pos.inst + ',' + p.pos.wy.toFixed(2) + ',' + p.pos.wx.toFixed(2);
  if (prev) { const d = GEO.dist(prev.pos, p.pos); line += '\n    ' + (d === null ? 'different continent from the previous point' : Math.round(d) + ' yd from the previous point (about ' + Math.round(d / 7) + ' s running)'); }
  console.log(line);
  prev = p;
}
