#!/usr/bin/env python3
"""Pull quest and NPC facts from Wowhead's WoW Forever pages (needs internet access from the sandbox).

    python3 wowhead.py quest 404 99141          name, required level, quest level, XP, start/end, chain, objectives
    python3 wowhead.py npc 1496 272101          name, level, reaction, and a spawn point (zone %) ready for .goto
    python3 wowhead.py search "Deathguard Lizabetha"    find quest / NPC / item / object ids by name

Output is JSON. An id that doesn't exist on WoW Forever comes back as {"id": ..., "error": "..."};
the other ids in the same call are still looked up.

quest:  requires_level = lowest level that can accept it (use this for routing); quest_level = the quest's own level.
        chain = the whole series in order; the entry with "this": true is the quest you asked for, and
        "or" lists alternatives Wowhead shows on the same row. objectives = numbered like RXP's .complete ID,N
        (items the giver hands you, "(Provided)", are left out because they aren't objectives).
npc:    spawn = a real spawn point near the middle of all spawns; goto = the same as an RXP .goto line.

If this can't reach wowhead.com (no network in the sandbox), fetch the same pages with your web tool instead:
https://www.wowhead.com/forever/quest=ID and https://www.wowhead.com/forever/npc=ID. See reference/wowhead.md
for what to read off the page.
"""
import html
import json
import re
import sys
import urllib.error
import urllib.parse
import urllib.request

BASE = 'https://www.wowhead.com/forever/'
UA = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
RACES = {1: 'Human', 2: 'Orc', 3: 'Dwarf', 4: 'NightElf', 5: 'Undead', 6: 'Tauren', 7: 'Gnome', 8: 'Troll'}
CLASSES = {1: 'Warrior', 2: 'Paladin', 3: 'Hunter', 4: 'Rogue', 5: 'Priest', 7: 'Shaman', 8: 'Mage', 9: 'Warlock', 11: 'Druid'}
REACT = {1: 'friendly', 0: 'neutral', -1: 'hostile'}


class NotFound(Exception):
    pass


def get(path):
    req = urllib.request.Request(BASE + path, headers=UA)
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            if 'notFound=' in r.geturl():
                raise NotFound(path)
            return r.read().decode('utf-8', 'replace')
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise NotFound(path)
        raise


def title(s, kind):
    m = re.search(r'<title>([^<]*)', s)
    return html.unescape(m.group(1).split(' - ' + kind)[0]) if m else '?'


def mapper(s):
    m = re.search(r'g_mapperData\s*=\s*(\{.*?\});', s, re.S)
    if not m:
        return []
    out = []
    for v in json.loads(m.group(1)).values():
        for e in v:
            pts = e.get('coords') or []
            if pts:
                # a real spawn point near the middle of the spawns (the plain average can fall between two camps)
                cx = sum(p[0] for p in pts) / len(pts)
                cy = sum(p[1] for p in pts) / len(pts)
                best = min(pts, key=lambda p: (p[0] - cx) ** 2 + (p[1] - cy) ** 2)
                out.append({'map': e.get('uiMapName'), 'uiMapId': e.get('uiMapId'), 'count': len(pts),
                            'spawn': best, 'goto': '.goto %s,%.2f,%.2f' % (e.get('uiMapName'), best[0], best[1]),
                            'points': pts[:12]})
    return out


def fact_ids(s, label, kind):
    """Ids in a quick-facts entry such as 'Race: [race=2]' or 'Races: [race=2], [race=8]'."""
    m = re.search(label + r's?: (.*?)\[\\?/li\]', s)
    return [int(x) for x in re.findall(kind + r'=(\d+)', m.group(1))] if m else []


def quest(qid):
    s = get('quest=%d' % qid)
    d = {'id': qid, 'name': title(s, 'Quest')}
    m = re.search(r'Requires level (\d+)', s); d['requires_level'] = int(m.group(1)) if m else None
    m = re.search(r'Level: (\d+)', s); d['quest_level'] = int(m.group(1)) if m else None
    m = re.search(r'"reqlevel":\d+,"side":\d+,"xp":(\d+)', s) or re.search(r'"xp":(\d+)', s)
    d['xp'] = int(m.group(1)) if m else None
    for key, label in (('start', 'Start'), ('end', 'End')):
        m = re.search(label + r': \[url=\\/forever\\/(npc|object|item)=(\d+)[^\]]*\]([^\[]*)', s)
        d[key] = {'type': m.group(1), 'id': int(m.group(2)), 'name': html.unescape(m.group(3))} if m else None
    m = re.search(r'Side: \[span class=icon-(\w+)', s); d['side'] = m.group(1) if m else 'both'
    d['races'] = [RACES.get(i, 'race %d' % i) for i in fact_ids(s, 'Race', 'race')]
    d['classes'] = [CLASSES.get(i, 'class %d' % i) for i in fact_ids(s, 'Class', 'class')]

    # The series box: one row per step; a row can hold alternatives, and this quest is shown in bold without a link.
    d['chain'] = []
    m = re.search(r'<table class="series">(.*?)</table>', s, re.S)
    if m:
        for row in re.findall(r'<tr>(.*?)</tr>', m.group(1), re.S):
            entries = [{'id': int(a), 'name': html.unescape(b)} for a, b in re.findall(r'quest=(\d+)/[^"]*">([^<]*)</a>', row)]
            if re.search(r'<b>', row):
                entries.insert(0, {'id': qid, 'name': d['name'], 'this': True})
            if entries:
                first = dict(entries[0])
                if len(entries) > 1:
                    first['or'] = entries[1:]
                d['chain'].append(first)

    # Objectives in quest-log order = objective N for .complete ID,N
    d['objectives'] = []
    m = re.search(r'<table class="icon-list">(.*?)</table>', s, re.S)
    if m:
        for row in re.findall(r'<tr[^>]*>(.*?)</tr>', m.group(1), re.S):
            if '(Provided)' in row:
                continue
            a = re.search(r'href="/forever/(npc|item|object|spell)=(\d+)[^"]*"[^>]*>([^<]*)</a>([^<]*)', row)
            n = re.search(r'icon-list-quantity">(\d+)<', row)
            if a:
                d['objectives'].append({'n': len(d['objectives']) + 1, 'type': a.group(1), 'id': int(a.group(2)),
                                        'name': (html.unescape(a.group(3)) + html.unescape(a.group(4))).strip(),
                                        'count': int(n.group(1)) if n else 1})
            else:
                txt = ' '.join(html.unescape(re.sub(r'<[^>]+>', ' ', row)).split())
                if txt:
                    d['objectives'].append({'n': len(d['objectives']) + 1, 'type': 'text', 'name': txt})
    return d


def npc(nid):
    s = get('npc=%d' % nid)
    d = {'id': nid, 'name': title(s, 'NPC')}
    m = re.search(r'"maxlevel":(\d+),"minlevel":(\d+)', s)
    d['level'] = (int(m.group(2)), int(m.group(1))) if m else None
    m = re.search(r'"react":\[([^\]]*)\]', s)
    if m:
        vals = [v.strip() for v in m.group(1).split(',')]
        conv = lambda v: REACT.get(int(v), v) if re.fullmatch(r'-?\d+', v) else None
        d['react'] = {'alliance': conv(vals[0]) if vals else None, 'horde': conv(vals[1]) if len(vals) > 1 else None}
    else:
        d['react'] = None
    d['locations'] = mapper(s)
    return d


def search(q):
    s = get('search?q=' + urllib.parse.quote(q))
    out = []
    for m in re.finditer(r'template:\s*"(\w[\w-]*)".*?getPageData\("([^"]+)"\)', s, re.S):
        kind, guid = m.group(1), m.group(2)
        if kind not in ('quest', 'npc', 'item', 'object'):
            continue
        dm = re.search(r'<script type="application/json" id="data\.' + re.escape(guid) + r'">(.*?)</script>', s, re.S)
        if not dm:
            continue
        try:
            rows = json.loads(dm.group(1))
        except ValueError:
            continue
        for r in rows[:15]:
            e = {'type': kind, 'id': r.get('id'), 'name': r.get('name') or r.get('displayName')}
            if isinstance(e['name'], str) and e['name'][:1].isdigit():
                e['name'] = e['name'][1:]  # items carry their quality digit in front of the name
            if kind == 'quest':
                e.update({'level': r.get('level'), 'requires_level': r.get('reqlevel'),
                          'side': {1: 'alliance', 2: 'horde', 3: 'both'}.get(r.get('side'), r.get('side')), 'xp': r.get('xp')})
            elif kind == 'npc':
                e['level'] = (r.get('minlevel'), r.get('maxlevel'))
            out.append(e)
    return out


def lookup_many(fn, args, kind):
    res = []
    for a in args:
        if not re.fullmatch(r'\d+', a):
            res.append({'id': a, 'error': kind + ' ids are numbers (use "search" to find one by name)'})
            continue
        try:
            res.append(fn(int(a)))
        except NotFound:
            res.append({'id': int(a), 'error': 'not found on Wowhead\'s WoW Forever database (wrong id, or not in Forever)'})
    return res


if __name__ == '__main__':
    if len(sys.argv) < 3 or sys.argv[1] in ('-h', '--help'):
        print(__doc__); sys.exit(0)
    kind, args = sys.argv[1], sys.argv[2:]
    try:
        if kind == 'quest':
            res = lookup_many(quest, args, 'Quest')
        elif kind == 'npc':
            res = lookup_many(npc, args, 'NPC')
        elif kind == 'search':
            res = search(' '.join(args))
        else:
            sys.exit('First argument must be quest, npc or search')
    except Exception as e:  # network blocked, page layout changed...
        sys.exit('Could not read Wowhead (%s). Use your web fetch tool on %s instead.' % (e, BASE))
    print(json.dumps(res, indent=1, ensure_ascii=False))
    if res and all(isinstance(r, dict) and 'error' in r for r in res):
        sys.exit(1)
