RXPGuides.RegisterGuide([[
#forever
#version 1
#group My Guides
<< Horde Paladin
#name 1-12 Zone Name (Race Class)
#next Next Guide Name

step
    .goto Tirisfal Glades,30.22,71.65
    >>Talk to |cRXP_FRIENDLY_NPC Name|r
    .accept 0000 >>Accept Quest Name
    .target NPC Name
step
    #completewith NextLabel
    >>Side objective text
    .complete 0000,1 --Objective Name (N)
step
    #label NextLabel
    #loop
    .goto Tirisfal Glades,55.00,42.00,0
    .goto Tirisfal Glades,56.00,40.00,40,0
    .goto Tirisfal Glades,54.00,41.00,40,0
    >>Kill |cRXP_ENEMY_Mob Name|r. Loot them for |cRXP_LOOT_Item|r
    .complete 0000,1 --Objective Name (N)
    .mob Mob Name
step
    .goto Tirisfal Glades,30.84,66.20
    >>Talk to |cRXP_FRIENDLY_NPC Name|r
    .turnin 0000 >>Turn in Quest Name
    .target NPC Name
]])
