# Planning a fast leveling route

A good RXP route is mostly about order: batch every pickup and turn-in at a hub, never walk somewhere twice when once would do, and never arrive at a quest giver below the quest's required level.

## 1. Collect the facts first

For every quest in the zone(s) and level range, get (Wowhead quest page, see wowhead.md):

- quest id and name, required level ("Requires level N"), quest level
- start NPC/object and end NPC, with coordinates
- chain: what comes before and after (the "series" box), and whether a follow-up only unlocks after a turn-in
- objectives in quest-log order, and where they're done (mob/object locations)
- XP reward
- faction / race / class restrictions (class quests matter: training, class chains)

Shortcuts: `node $SKILL/scripts/quest_info.js --zone "Zone Name" --horde` lists every quest RestedXP routes in a zone with giver/turn-in coordinates; the RestedXP guide for the zone in `library/forever/` already shows a proven order, NPC names and objective numbers. Use them as the starting point and verify level requirements on Wowhead.

## 2. Group quests by area

Sort objectives into areas (e.g. "north gnoll camp", "west farms", "east lake") and hubs (towns with several givers). Each area visit should finish everything available there. Kill/collect objectives that share an area become one `#loop` step plus `#completewith` side objectives for the others.

## 3. Walk the levels

Track the character's XP through the route. Classic XP needed for each level:

| Level | XP to next | Level | XP to next |
|---|---|---|---|
| 1 | 400 | 11 | 8,700 |
| 2 | 900 | 12 | 9,800 |
| 3 | 1,400 | 13 | 11,000 |
| 4 | 2,100 | 14 | 12,300 |
| 5 | 2,800 | 15 | 13,600 |
| 6 | 3,600 | 16 | 15,000 |
| 7 | 4,500 | 17 | 16,400 |
| 8 | 5,400 | 18 | 17,800 |
| 9 | 6,500 | 19 | 19,300 |
| 10 | 7,600 | 20 | 20,800 |

Kill XP for a mob at or above your level ≈ (yourLevel × 5 + 45) × (1 + 0.05 × levelDifference); lower mobs give less, grey mobs nothing. A loop step with 8-15 kills is roughly 600-1,200 XP at levels 5-10. WoW Forever may differ slightly; keep a margin.

RestedXP's guides grind to exact targets such as `.xp 7+3520`. Those numbers are tuned to RestedXP's own route: once you reorder, skip or add quests, the player arrives with different XP. Don't copy them blindly. Recount from the quests your route has turned in so far, and plan for about 10% less XP than the sum (missed mobs, quests done out of order). Where a pickup depends on the level, a short `.xp N` grind just before it costs nothing for players who are already there.

At each hub, make sure the character meets the required level for every pickup. When the estimate is close:

- Put a `.xp N` grind step right before the pickup, on the nearest mobs of the right level. It finishes instantly for players who are already N.
- Turn in quests first at a hub (their XP often pushes the level), then pick up.
- Or make the pickup its own step with `.xp <N,1` so it skips itself, and add a second pickup at the next visit.

## 4. Order the trip

- Start each trip from a hub with every pickup that trip needs, including higher-level quests if the level allows.
- Do far objectives in one loop that ends near the next hub (or the next area). Walking back costs time; a loop that ends at town doesn't.
- Pick up a quest the first time you pass its giver if you'll be able to finish it on this trip or a later one without detours.
- Turn-ins that send you back to the same NPC later: pick the follow-up up immediately.
- Chains: a follow-up's objectives may be in the same area as the first part. Do part 1, turn in, accept part 2, and do it before leaving the area if the NPC is nearby.
- Use guarded turn-in steps (`.isQuestComplete ID`) when you pass a turn-in NPC and the quest might already be done.

## 5. Travel shortcuts

- **Deathskip** (softcore only): dying and taking the spirit resurrection teleports to the graveyard. No resurrection sickness up to level 10; from 11 it costs 1 minute per level above 10 (up to 10 minutes) plus 25% durability. Good for returning to town after a far area. Mark with `#softcore`; add a `#hardcore` alternative ("Travel back to Brill").
  - You respawn at the graveyard the game assigns to where you died: usually the nearest one of your faction, but not always. This skill has no graveyard data, so only deathskip where you know where the player lands. Best source: RestedXP's own deathskips in `library/forever/` (`grep -n -A4 "\.deathskip" $SKILL/library/forever/FILE.lua`). The step after each one starts at the graveyard you land in. Reuse those spots. If you're unsure, write the step as "run back" and mention it.
  - Write the deathskip as a `#softcore` `#completewith next` side step (so the next step's arrow already points at the town), with `.target Spirit Healer`.
  - Starting areas don't all have a graveyard of their own, so an early death can send the player out to the main town. Before planning a deathskip in a starting area, check that RestedXP's guide for it uses one there.
- **Hearthstone** (1 hour cooldown): a new character's hearthstone is bound to its starting area. Set it at the hub you'll return to most. Plan its use; don't promise a hearth twice within an hour.
- **Flight paths**: get them on the way (`.fp Name`) even if you don't need them yet.

## 6. Skip what isn't worth it

Skip a quest when the time it costs is worth less than grinding: long detours for little XP, quests that only unlock much later content, elite group quests for solo players, and items/quests only for other classes. Say which quests you skipped and why when you hand over the guide. Never skip a quest that opens a chain you're doing, and don't skip class quests that give key abilities or weapons without telling the player.

## 7. Small things that save minutes

- Class training at the levels new spells come (classic: every even level, and some odd levels for certain spells). Put the trainer visit in a hub stop.
  - Use `.trainer >>Train your class spells` (completes when the player closes any trainer window). It never blocks.
  - `.train SPELLID >>Train Name` completes only once the spell is known. If the player can't afford it, or the trainer doesn't teach it yet, the step stays stuck. Use it only for one or two key cheap spells, and never as the only thing in a step that gates a quest.
  - Trainer names and spots: RestedXP's guides have them (`grep -n -B3 "\.trainer" $SKILL/library/forever/FILE.lua`), or Wowhead's NPC search.
- Buy food/water before long trips; vendor trash when passing a vendor.
- Patrolling NPCs: `-1` closest-point gotos along the patrol.
- Items that start quests (dropped letters): a `#completewith` step with `.collect` + `.accept` + `.use`.
- Keep the quest log under 20; the checker reports the maximum.

## 8. Check the route

Run `node $SKILL/scripts/check_guide.js guide.lua --race X --class Y --list`. Look at the running distance per step: big numbers mean a detour. Fix errors, then decide each warning (duplicate turn-ins are fine if they're deliberate backups).
