# Looking things up on Wowhead (WoW Forever)

Wowhead has a WoW Forever section with its own quest and NPC data and Forever map coordinates. Always use the `/forever/` URLs.

- Quest: `https://www.wowhead.com/forever/quest=404`
- NPC: `https://www.wowhead.com/forever/npc=1496`
- Object: `https://www.wowhead.com/forever/object=711`
- Item: `https://www.wowhead.com/forever/item=2875`
- Search: `https://www.wowhead.com/forever/search?q=Deathguard+Lizabetha`

If the sandbox can reach the internet, `python3 $SKILL/scripts/wowhead.py quest 404`, `npc 1496` or `search "name"` pulls the facts below as JSON (quest: required level, quest level, XP, side, race/class limits, start/end, the whole chain with this quest marked, objectives numbered for `.complete`; NPC: level, reaction and a real spawn point as a ready `.goto`; search: quests, NPCs, items and objects with their type, and level/XP for quests). "Not found on Wowhead's WoW Forever database" means the id is wrong or the quest/NPC isn't in Forever.

If it can't, open the same URLs with your web tool. Notes:

- With `curl`, send a browser User-Agent and follow redirects (`curl -sL -A "Mozilla/5.0"`). Without them Wowhead returns an empty 301 or blocks the request.
- Web tools that summarise pages often mix up **"Requires level"** (the lowest level that can accept the quest) and **"Level"** (the quest's own level, which sets its XP and difficulty). Ask for both by name and use "Requires level" for routing.

## Quest page: what to read

| Fact | Where on the page |
|---|---|
| Required level | Quick facts: "Requires level 6". The player can't accept below this. |
| Quest level | Quick facts: "Level: 8". |
| Start / end | Quick facts: "Start: Deathguard Dillinger", "End: ...". Follow the links for NPC ids and coordinates. |
| Chain | The "Series" box lists the chain in order; the current quest is highlighted. |
| Objectives | The quest text's objectives list. Objective numbers for `.complete ID,N` follow this order (first = 1). Kill objectives count as objectives too. |
| XP | "Rewards / Gains": "Experience: 405". |
| Restrictions | "Side: Horde", "Race: Undead", "Class: Paladin" in quick facts. |
| Hints | Comments often give `/way x y` coordinates and tips (patrolling NPCs, drop rates, bugs on Forever). |

Quests new to Forever have high ids (90000+) and some classic quests changed. Don't assume Classic Era data applies.

## NPC page: coordinates

The map on an NPC page shows every spawn. In the page source it's `g_mapperData = {...}` with `coords` as zone percent pairs and `uiMapId`/`uiMapName` (e.g. 1420 = Tirisfal Glades). Those numbers go straight into `.goto Tirisfal Glades,52.5,54.5`. For patrolling NPCs, several points along the route make good `-1` gotos.

The page text also says the NPC's level and whether it's friendly (reaction), useful for "kite the mob into the guard" style tips.

## Objects and items

- Quest objects (e.g. "Wanted" posters, herbs to loot): object page, same map data.
- Items: the "Dropped by" tab lists which mobs drop a quest item and how often. Useful for choosing which mobs a loop step targets.

## Coordinates from other sources

- RestedXP's Forever guides (`library/forever/`) use world coordinates: `.goto 1420/0,1184.71,2205.63` (map 1420, then world Y, world X). Convert with `node $SKILL/scripts/coords.js "1420/0,1184.71,2205.63"` or a whole file with `node $SKILL/scripts/coords.js --convert file.lua`.
- `node $SKILL/scripts/quest_info.js ID` gives giver/turn-in coordinates RestedXP uses (already converted to Forever zone %).
- Players can read their own position in game with the macro `/run local m=C_Map.GetBestMapForUnit("player") local p=C_Map.GetPlayerMapPosition(m,"player") print(format(".goto %s,%.2f,%.2f",C_Map.GetMapInfo(m).name,p.x*100,p.y*100))` and paste the result.
