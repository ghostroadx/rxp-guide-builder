# RXP guide syntax and how the addon runs it

Everything here matches RestedXP's addon code (GuideLoader.lua, GuideWindow.lua, functions.lua, map.lua) and the RXP Visual Guide Builder's checker. Read the "Rules that break guides" section before writing.

## File layout

```lua
RXPGuides.RegisterGuide([[
#forever
#version 1
#group My Guides
<< Horde Paladin
#name 1-12 Tirisfal Glades (Undead Paladin)
#next 12-14 Silverpine Forest

step
    .goto Tirisfal Glades,30.22,71.65
    >>Talk to |cRXP_FRIENDLY_Undertaker Mordo|r
    .accept 363 >>Accept Rude Awakening
    .target Undertaker Mordo
step
    ...
]])
```

Header lines (before the first `step`):

| Line | Meaning |
|---|---|
| `#forever` | Zone coordinates are WoW Forever maps. Always include it for Forever guides (Mulgore, Redridge, Eastern Plaguelands and Stormwind are framed differently from Classic Era). |
| `#version N` | Bump when you publish changes. |
| `#group Name` | **Required.** Menu group the guide shows under. |
| `#name Name` | **Required.** Guide name. RXP ignores a guide without `#name` and `#group`. |
| `#next Name` | Guide to load when this one finishes (exact `#name`; prefix `Group\` for another group). |
| `<< filter` | Guide only loads for these characters (same filter syntax as steps). |
| `#displayname Text` | Optional label shown instead of `#name`. |
| `#subgroup Name` | Optional sub-heading inside the group's menu (RestedXP uses "Speedrun Guide 1-20"). |
| `#defaultfor Race/Class` | RXP offers this guide first to those characters (filter syntax: `#defaultfor Scourge`, `#defaultfor Dwarf/Gnome`). Leave it out for custom guides so you don't fight RestedXP's own defaults. |

Several header lines can carry their own `<<` filter, e.g. `#group RestedXP Forever Guide (H) << Horde`.

One file can hold several `RXPGuides.RegisterGuide([[ ... ]])` blocks. Indent step contents with 4 spaces. Files use Windows line endings when exported (not required).

## Filters (`<<`)

`step << Horde Paladin`, or at the end of any line: `.accept 98601 >>Accept A Difficult Path << Paladin`.

- Space = AND, `/` = OR, `!` = NOT. Priority `!` > space > `/`. `Dwarf Paladin/Gnome Mage` = (Dwarf and Paladin) or (Gnome and Mage).
- Tokens: classes (`Warrior Paladin Hunter Rogue Priest Shaman Mage Warlock Druid`), races (`Human Dwarf NightElf Gnome Orc Undead Tauren Troll`; the game's internal name `Scourge` also works), factions (`Alliance Horde`).
- A line whose filter fails is removed entirely. A step whose filter fails doesn't exist for that character.

## Step tags (`#`)

| Tag | What it does |
|---|---|
| `#label Name` | Names the step for `#completewith`/`#requires`/`.skipto`. |
| `#sticky` | Stays on screen after the guide moves on, until all its elements are done. |
| `#completewith next` / `#completewith Label` | A side objective: shown together with the following steps, and removed once the guide passes the target step (or the target sticky step is done), or when its own elements are all done. RXP treats it as sticky. |
| `#requires Label` | Hide this (sticky) step until the named step is done. Use it to show a follow-up objective only after its quest is accepted. |
| `#loop` | The step's waypoints form a circuit (grind/collect area). The arrow cycles through the waypoints. |
| `#optional` | Hidden from the step list at the bottom of the window. RestedXP uses it for technical steps (labels, jumps, placeholders). A step with no elements at all is optional automatically. It does **not** change how the step completes. |
| `#softcore` / `#hardcore` | Only shown when the player's RXP hardcore setting is off / on. Put deathskip steps under `#softcore` if hardcore players might use the guide. |
| `#level N` | Only shows from level N. Use only on sticky steps; use `.maxlevel`/`.xp` on normal steps. |
| `#xprate <1.5` / `#xprate >1.49` | Show only below / above an XP rate. WoW Forever's normal rate is 1, so `<` steps show and `>` steps hide. RestedXP writes separate steps for boosted XP; follow the `<` ones. |
| `#season 0` / `#season 2` | Show only in that game season. WoW Forever is season 0, so `#season 0` steps show and `#season 1`/`#season 2` steps (Season of Mastery / Discovery) never do. `#som` = Season of Mastery only (hidden on Forever); `#era` = everything except Season of Mastery (shown on Forever). |
| `#hidewindow` | Hidden from the step window (used for helper steps that only set arrows or labels). |

## Text lines

| Line | Shows |
|---|---|
| `>>text` | A line of text in the step. Can be on its own line or after an element (`.accept 363 >>Accept Rude Awakening`). |
| `+text` | A checkbox the player ticks by hand. Gives a step something to complete when nothing else can. |
| `*text` | A note in the step window only. |
| `-- comment` | Comment. Everything after `--` on a line is removed, including inside `>>` text, so never use `--` as punctuation in guide text. |

Colour codes in text: `|cRXP_FRIENDLY_Name|r` (friendly NPC, green), `|cRXP_ENEMY_Name|r` (enemy, orange), `|cRXP_LOOT_Item|r` (loot, cyan), `|cRXP_PICK_Object|r` (object to click, purple), `|cRXP_WARN_text|r` (warning, yellow), `|cRXP_BUY_text|r` (buy, green). Item icons: `|T133490:0|t[Item Name]`.

## Elements (`.command`)

Quests:

| Element | Completes when |
|---|---|
| `.accept ID >>Accept Name` | The quest is in the log (or already done). RXP auto-accepts it when you talk to the giver. |
| `.turnin ID >>Turn in Name` | The quest is turned in. `.turnin ID,2` picks reward 2. |
| `.complete ID,OBJ --Name (N)` | Objective OBJ of the quest is done. The comment is for humans; the window shows the quest log's "Name: x/N". |
| `.collect ITEMID,N[,QUESTID]` | You have N of the item (or are on QUESTID). |
| `.abandon ID` | You abandon the quest. |

Movement and map:

| Element | Behaviour |
|---|---|
| `.goto Zone,x,y` | Waypoint with arrow and map pin. Never completes on its own. |
| `.goto Zone,x,y,R` | Completes when you're within R yards. Shows its text (or "Go to x,y"). The step finishes when you arrive. |
| `.goto Zone,x,y,R,0` | Hidden waypoint: the arrow walks through it, no pin, no objective. Used for paths and `#loop` circuits. |
| `.goto Zone,x,y,0` | Map pin only, no arrow. |
| `.goto Zone,x,y,-1` | "Closest point": with several `-1` gotos the arrow picks the nearest. Good for NPCs that patrol. |
| `.goto 1420/0,WY,WX` | Same, in world coordinates (RestedXP's format). `scripts/coords.js` converts. |
| `.zone Name` | Completes when you enter the zone. `.zoneskip Name` skips the step if you're already there (add `,1` to reverse). |
| `.subzone ID` | Completes in that subzone. |
| `.line Zone,x1,y1,x2,y2...` / `.loop R,Zone,x1,y1,...` | Draw a path / circuit on the map. |

A `#loop` grind circuit in RestedXP's style starts with a `,0` map pin (no arrow) that marks the area on the map, followed by hidden waypoints `R,0` that the arrow walks round and round. The step completes on its own element (`.xp`, `.complete`, `.collect`), never on the loop:

```
step
    #loop
    .goto Tirisfal Glades,31.72,63.98,0
    .goto Tirisfal Glades,31.72,63.98,40,0
    .goto Tirisfal Glades,30.69,63.88,40,0
    .goto Tirisfal Glades,30.90,62.20,40,0
    .goto Tirisfal Glades,31.80,61.83,40,0
    .goto Tirisfal Glades,32.85,63.02,40,0
    >>Kill |cRXP_ENEMY_Mindless Zombies|r and |cRXP_ENEMY_Wretched Zombies|r
    .complete 364,1 --Kill Mindless Zombie (x8)
    .mob +Mindless Zombie
    .complete 364,2 --Kill Wretched Zombie (x8)
    .mob +Wretched Zombie
```

(The Mindless Ones in Deathknell, from RestedXP's 1-6 Tirisfal guide, shortened and converted to zone %.)

Leveling, travel, NPC services:

| Element | Behaviour |
|---|---|
| `.xp 6 >>Grind to level 6` | Completes at level 6. `.xp 6+500` = level 6 and 500 xp; `.xp 6.5` = halfway into 6; `.xp 6-300` = 300 xp before 6. |
| `.xp <6,1` | Condition: skips the whole step if you're **below** level 6 (use for level-gated pickups). `.xp 6,1` skips it once you're 6. |
| `.maxlevel N` | Skips the step above level N. |
| `.deathskip >>Die and respawn at the Spirit Healer` | Completes when you take the spirit resurrection. Softcore only. |
| `.hs >>Hearth to Brill` | Completes when you cast your hearthstone. |
| `.home >>Set your Hearthstone to Brill` | Completes when you set your home at an innkeeper. |
| `.vendor [NPCID] >>Sell junk` | Completes when you close that merchant. |
| `.trainer >>Train your class spells` | Completes when you close a trainer window. `.train SPELLID` completes when you know the spell. |
| `.fp Name` / `.fly Name` | Get a flight path / fly somewhere. |
| `.buy ITEMID,N`, `.use ITEMID`, `.destroy ITEMID` | Item helpers. `.use` adds a clickable item button (it never completes on its own). |
| `.equip SLOT,ITEMID >>Equip the X` | With text: completes when the item is in that slot (slot 16 = main hand, 15 = back, 5 = chest). Without text it's a condition that skips the step once equipped. |
| `.gossipoption ID >>Pick the option` | With text: completes when that gossip option shows (RXP picks it if gossip automation is on). Without text it only automates the choice. |

Targets and conditions (never complete, never block):

| Element | Behaviour |
|---|---|
| `.target Name` | Friendly target button / macro for an NPC. `.target +Name` = only while the line above it is unfinished. |
| `.mob Name` / `.unitscan Name` | Enemy target button / rare-scanner alert. |
| `.isOnQuest ID` | Skip the step unless the quest is in the log. |
| `.isQuestComplete ID` | Skip unless the quest's objectives are done. |
| `.isQuestTurnedIn ID` | Skip unless already turned in. |
| `.isQuestAvailable ID` | Skip if already turned in. (It does **not** check prerequisites.) |
| `.itemcount ID,N` / `.itemcount ID,<N` | Skip unless you have at least N of the item / skip if you have N or more. |
| `.money <0.05` / `.money >0.05` | Amounts are in **gold**: 1 = 1g, 0.01 = 1s, 0.0001 = 1c. `<0.05` skips the step when you have **less** than 5 silver (an "only if you can afford it" step); `>0.05` skips it when you have 5 silver or more. |
| `.disablecheckbox` | The line above it no longer blocks the step (it still shows and tracks). |
| `.timer SECONDS,Text` | Timer bar attached to the accept/turnin above. |
| `.link URL >>text` | Clickable link. |

## How RXP decides a step is done

- A step is done when **every element is completed, skipped, or text-only**. Text-only: `>>` lines, `*` notes, plain gotos without a radius, `.target`, `.mob`, `.use`, conditions.
- So a step needs at least one element that can complete (accept, turnin, complete, collect, xp, goto with radius, deathskip, hs, home, vendor, trainer, zone, `+checkbox`...). Otherwise it is "done" the moment it starts and flashes past. **This also happens to a step that is only `.goto Zone,x,y` with no radius.**
- When the guide reaches a `#sticky`/`#completewith` step it shows it and immediately moves on to the next step, so side objectives display together with the following "current" step.
- A sticky/completewith step whose elements are all text-only disappears immediately (it counts as done). Give side objectives a real element (`.complete`, `.collect`, `.deathskip`, `+checkbox`).
- Conditions (`.isOnQuest`, `.xp <N,1`...) are checked when the step starts. If one fails, the step is skipped.

## The arrow

- The arrow points at the first waypoint of the steps on screen (side objectives first, then the current step) that isn't finished.
- **Each plain goto belongs to the last completable element written above it in the same step.** When that element completes, the arrow stops pointing at that goto. A goto written before any element belongs to nothing and stays active for the whole step.
- So in a step with several NPCs, write each `.goto` right **after** the line it belongs to:

```
step
    >>Talk to |cRXP_FRIENDLY_Burgess|r and |cRXP_FRIENDLY_Sevren|r in the town hall
    .accept 374 >>Accept Proof of Demise
    .target +Deathguard Burgess
    .goto Tirisfal Glades,60.93,52.01
    .accept 358 >>Accept Graverobbers
    .target +Magistrate Sevren
    .goto Tirisfal Glades,61.26,50.84
```

  In a one-NPC step the usual order is fine: `.goto` first, then `>>Talk to...`, `.accept`, `.target`.
- **A plain goto (no radius) with `>>text` on the same line never gets the arrow** (text-only lines count as finished). Put the text on its own `>>` line, or give the goto a radius.
- A goto with radius `0` has no arrow at all.

## Rules that break guides (check every time)

1. Every step can complete (see above). A lone `.goto` without radius flashes past.
2. Never put text on a no-radius goto line.
3. Multi-NPC steps: goto after the element it belongs to.
4. Don't `.accept` a quest above the player's level in that step: the step can't finish. Add a `.xp N` grind step first, or put the accept in its own step guarded with `.xp <N,1` and pick it up again later.
5. `--` starts a comment, even inside text.
6. Side objectives need a completable element and should end with `#completewith Label` at a step that actually comes later.
7. Quest and objective IDs must be real. Look them up (Wowhead, the bundled data or the RestedXP library). Never guess.
8. Objective numbers (`.complete ID,1`) follow the quest log order on Wowhead's quest page (first objective = 1).
9. `#name` and `#group` are required; `#forever` for Forever coordinates.
10. Deathskips are softcore only (`#softcore`), and resurrection sickness starts above level 10.

## Patterns

Side objective while doing something else, ending at a later step:

```
step
    #completewith Claws
    >>Loot |cRXP_PICK_Dry Branches|r under the trees around Brill
    .complete 86784,1 --Dry Branch (6)
...
step
    #label Claws
    .goto Tirisfal Glades,52.50,54.50
    >>Kill |cRXP_ENEMY_Rotting Dead|r. Loot them for |cRXP_LOOT_Putrid Claws|r
    .complete 404,1 --Putrid Claw (7)
    .mob Rotting Dead
```

Tracker that stays until a quest is fully done (objective + turn-in):

```
step
    #sticky
    >>Loot |cRXP_PICK_Dry Branches|r. Turn them in to |cRXP_FRIENDLY_Eleanor Shackleton|r once you have 6
    .complete 86784,1 --Dry Branch (6)
    .turnin 86784 >>Turn in Sticks and Bones
```

Follow-up objective that only appears once the quest is picked up:

```
step
    #completewith GordoLoop
    #label GordoWatch
    >>Watch for |cRXP_FRIENDLY_Gordo|r. Talk to him to make him stand still
    .accept 5481 >>Accept Gordo's Task
    .target Gordo
step
    #sticky
    #requires GordoWatch
    >>Loot |cRXP_PICK_Gloom Weed|r along the road
    .complete 5481,1 --Gloom Weed (3)
```

Kill/collect circuit:

```
step
    #loop
    .goto Tirisfal Glades,55.24,42.54,0
    .goto Tirisfal Glades,56.31,39.67,40,0
    .goto Tirisfal Glades,54.71,41.19,40,0
    .goto Tirisfal Glades,53.90,43.93,40,0
    >>Kill |cRXP_ENEMY_Rot Hide Graverobbers|r. Loot them for |cRXP_LOOT_Embalming Ichor|r
    .complete 358,1 --Rot Hide Graverobber (8)
    .complete 358,3 --Embalming Ichor (8)
    .mob Rot Hide Graverobber
```

Patrolling NPC (arrow to the nearest point of the route):

```
step
    .goto Tirisfal Glades,58.47,51.40,-1
    .goto Tirisfal Glades,58.20,49.80,-1
    .goto Tirisfal Glades,57.40,49.20,-1
    >>Talk to |cRXP_FRIENDLY_Deathguard Bartholomew|r. He walks around the graveyard
    .accept 86784 >>Accept Sticks and Bones
    .target Deathguard Bartholomew
```

Turn-in only if ready (otherwise skipped):

```
step
    .isQuestComplete 86784
    .goto Tirisfal Glades,57.27,55.49
    >>Talk to |cRXP_FRIENDLY_Eleanor Shackleton|r
    .turnin 86784 >>Turn in Sticks and Bones
```

Level-gated pickup that skips itself if the player is too low:

```
step
    .xp <6,1
    .goto Tirisfal Glades,58.20,51.45
    >>Talk to |cRXP_FRIENDLY_Deathguard Dillinger|r
    .accept 426 >>Accept The Mills Overrun
```

Deathskip back to town (softcore):

```
step
    #softcore
    #completewith BrillTurnins
    .deathskip >>Die and respawn at the |cRXP_FRIENDLY_Spirit Healer|r in Brill
step
    #label BrillTurnins
    .goto Tirisfal Glades,59.45,52.40
    ...
```

Run somewhere with an arrow (needs a radius so it completes):

```
step
    .goto Tirisfal Glades,34.78,56.09,15 >>Run to the cliff
```
