# RestedXP WoW Forever guides (reference library)

RestedXP's own WoW Forever guides, copied from the RXPGuides addon. Use them to see a proven quest order for a zone, NPC names, quest and objective ids, and coordinates. They use world coordinates (`.goto 1420/0,WY,WX`); convert with `node $SKILL/scripts/coords.js`.

License: CC BY-NC-SA 4.0 by RestedXP (see LICENSE-RestedXP.txt). Credit RestedXP and don't use commercially.

| File | Guides (#name) | Faction / who |
|---|---|---|
| forever/Horde-01-14_Undead.lua | 1-6 Tirisfal Glades; 6-12 Tirisfal Glades; 12-14 Silverpine Forest | Horde, Undead start |
| forever/Horde-01-12_Durotar.lua | 1-6 Durotar; 6-10 Durotar; 10-12 Durotar; 10-12 Tirisfal; 1-7 Durotar; 7-13 Durotar | Horde, Orc/Troll start |
| forever/Horde-1-12_Mulgore.lua | 1-6 Mulgore; 6-12 Mulgore; 1-7 Mulgore; 7-13 Mulgore | Horde, Tauren start |
| forever/Horde-12-22_Barrens.lua | 12-17 The Barrens; 17-22 Stonetalon/Barrens/Ashenvale; 13-20 The Barrens; 20-24 Stonetalon/Barrens | Horde |
| forever/Horde-Mage-12-21.lua | 12-17 The Barrens AoE; 17-21 Stonetalon/Barrens AoE | Horde Mage (AoE farming) |
| forever/Alliance-1-13_Human.lua | 1-6 Northshire; 6-11 Elwynn Forest; 11-13 Loch Modan | Alliance, Human start |
| forever/Alliance-1-14_DwarfGnome.lua | 1-6 Coldridge Valley; 6-11 Dun Morogh; 11-12 Elwynn; 12-14 Loch Modan; Hunter variants | Alliance, Dwarf/Gnome start |
| forever/Alliance-1-10_NightElf.lua | 1-6 Shadowglen; 6-11 Teldrassil | Alliance, Night Elf start |
| forever/Alliance-11-20.lua | 13-15 Westfall; 14-16 Darkshore; 16-19 Darkshore; 19-20 Redridge; 19-21 Darkshore/Ashenvale; 20-21 Darkshore/Ashenvale | Alliance |
| forever/Alliance-Mage-1-12.lua | 1-10 Elwynn Forest Mage AoE; 1-10 Dun Morogh Mage AoE; 10-12 Loch Modan Mage AoE | Alliance Mage |
| forever/Alliance-Mage-12-21.lua | 12-18 Darkshore Mage AoE; 18-21 Redridge Mage AoE | Alliance Mage |
| forever/Alliance-ADV-AoE-Mage-1-22.lua | Advanced AoE Mage routes 1-22 | Alliance Mage |
| forever/RestedXP-Skyborne.lua | 1-14 Zephras Isle; Skyborne class quests | Skyborne (Forever's new race) |

## Reading these guides

- Several guides cover the same zone (e.g. "1-6 Durotar" and "1-7 Durotar"). The pairs are for different XP rates: the one with `#xprate <1.99` (or `<1.5`) in its header or steps is for WoW Forever's normal XP rate. Follow that one; the other is for boosted XP.
- Inside a guide, skip steps tagged `#xprate >1.49`, `#season 2`, `#som`, `<< skip` or `step << skip`. They never show on Forever at normal XP.
- `#hardcore` / `#softcore` steps are alternatives. Follow `#softcore` for a softcore guide (deathskips) and `#hardcore` for a hardcore one.
- Their grind targets (`.xp 7+3520`) fit their own route only. See `reference/routing.md`.
- `<< Warlock` style filters mark class-only steps; copy only those for the class you're writing for.

Find a zone quickly: `grep -n "#name" $SKILL/library/forever/*.lua`. Find a quest: `grep -n "\.accept 404\b" $SKILL/library/forever/*.lua`.

`examples/UD_Paladin_Tirisfal_1-12.lua` is a complete custom route (Undead Paladin, Tirisfal Glades 1-12, ending in the Undercity) written with this skill's rules: side objectives, trackers, guarded turn-ins, level-gated pickups, grind steps and deathskips. It passes the checker with no errors; its warnings are deliberate backup turn-ins.
