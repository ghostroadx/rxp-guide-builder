-- 1-12 Tirisfal Glades (Undead Paladin): an example custom route made with the rxp-guide-builder skill.
-- Tirisfal quests from level 1 to about 12, ending in the Undercity and heading into Silverpine Forest.
RXPGuides.RegisterGuide([[
#forever
#version 1
#group My Guides
#name 1-12 Tirisfal Glades (Undead Paladin)
<< Horde Paladin

step
    .goto Tirisfal Glades,30.22,71.65
    >>Talk to |cRXP_FRIENDLY_Undertaker Mordo|r
    .accept 363 >>Accept Rude Awakening
    .target Undertaker Mordo
    .goto Tirisfal Glades,29.17,68.50,20,0
    .goto Tirisfal Glades,29.76,64.24,20,0
    .goto Tirisfal Glades,29.04,59.65,20,0
    .goto Tirisfal Glades,28.26,58.68,20,0
step
    .xp 4 >>Grind to level 4
    .goto Tirisfal Glades,28.60,58.40
step
    .vendor 2113 >>Vendor trash
    .goto Tirisfal Glades,32.21,65.86
step
    >>Talk to your class trainer
    .train 465 >>Train Devotion Aura
    .train 19740 >>Train Blessing of Might
    .train 20271 >>Train Judgement
    .goto Tirisfal Glades,31.14,66.31
step
    .goto Tirisfal Glades,30.84,66.20
    >>Talk to |cRXP_FRIENDLY_Shadow Priest Sarvis|r
    .turnin 363 >>Turn in Rude Awakening
    .target Shadow Priest Sarvis
step
    .goto Tirisfal Glades,34.78,56.09,15 >>Run to the cliff
step
    .goto Tirisfal Glades,35.09,52.09
    >>Jump off the cliff to die. If you don't die, attack a farmer to die.
    .deathskip >>Die and respawn at the Spirit Healer
step
    .goto Tirisfal Glades,58.20,51.45
    >>Talk to |cRXP_FRIENDLY_Deathguard Dillinger|r
    .accept 404 >>Accept A Putrid Task
    .target Deathguard Dillinger
step
    .goto Tirisfal Glades,58.47,51.40,-1
    .goto Tirisfal Glades,58.20,49.80,-1
    .goto Tirisfal Glades,57.40,49.20,-1
    >>Talk to |cRXP_FRIENDLY_Deathguard Bartholomew|r
    >>|cRXP_WARN_He walks around the Brill graveyard. The arrow points to the nearest spot on his route|r
    .accept 86784 >>Accept Sticks and Bones
    .target Deathguard Bartholomew
step
    #sticky
    #label SticksBones
    >>Loot |cRXP_PICK_Dry Branches|r on the ground under the trees around Brill
    >>|cRXP_WARN_Once you have 6, turn them in to|r |cRXP_FRIENDLY_Eleanor Shackleton|r |cRXP_WARN_at the campfire south-west of Brill|r
    .complete 86784,1 --Dry Branch (6)
    .turnin 86784 >>Turn in Sticks and Bones
step
    .goto Tirisfal Glades,60.56,51.76
    >>Talk to |cRXP_FRIENDLY_Executor Zygand|r
    .accept 99141 >>Accept Patience
    .accept 99134 >>Accept Discipline
    .target Executor Zygand
step
    #sticky
    #label Reports
    >>Get reports for |cRXP_FRIENDLY_Executor Zygand|r from |cRXP_FRIENDLY_Deathguard Dillinger|r, |cRXP_FRIENDLY_Deathguard Kristof|r and |cRXP_FRIENDLY_Gordo|r
    >>|cRXP_WARN_Select "I need a report for Executor Zygand" with each of them|r
    .complete 99141,1 --Dillinger's Report
    .complete 99141,2 --Kristof's Report
    .complete 99141,3 --Gordo's Report
step
    #completewith Kristof
    .use 286176 >>|cRXP_WARN_Use the|r |T133490:0|t[Executor's Motivator] |cRXP_WARN_on any|r |cRXP_FRIENDLY_Deathguard|r |cRXP_WARN_in and around Brill|r
    .complete 99134,1 --Deathguards motivated (5)
step
    .goto Tirisfal Glades,61.03,52.35
    >>Talk to |cRXP_FRIENDLY_Abigail Shiel|r
    .vendor 2118 >>Vendor trash
    .target Abigail Shiel
step
    .goto Tirisfal Glades,61.53,53.22,8 >>Enter the inn
step
    #label Hearth
    .goto Tirisfal Glades,61.71,52.06
    >>Talk to |cRXP_FRIENDLY_Innkeeper Renee|r
    .home >>Set your Hearthstone to Brill
    .target Innkeeper Renee
step
    .goto Tirisfal Glades,61.71,52.06
    >>Talk to |cRXP_FRIENDLY_Innkeeper Renee|r
    >>|cRXP_BUY_Buy 20|r |T134531:0|t[Forest Mushroom Cap] |cRXP_BUY_from her|r
    .collect 4604,20 --Forest Mushroom Cap (20)
    .target Innkeeper Renee
step
    #label Kristof
    .goto Tirisfal Glades,65.20,60.20
    >>Talk to |cRXP_FRIENDLY_Deathguard Kristof|r
    >>|cRXP_WARN_Select "I need a report for Executor Zygand"|r
    .complete 99141,2 --Kristof's Report
    .target Deathguard Kristof
step
    #label Discipline
    .use 286176 >>|cRXP_WARN_Finish using the|r |T133490:0|t[Executor's Motivator] |cRXP_WARN_on|r |cRXP_FRIENDLY_Deathguards|r |cRXP_WARN_in and around Brill|r
    .complete 99134,1 --Deathguards motivated (5)
step
    .goto Tirisfal Glades,60.56,51.76
    >>Talk to |cRXP_FRIENDLY_Executor Zygand|r
    .turnin 99134 >>Turn in Discipline
    .target Executor Zygand
step
    .goto Tirisfal Glades,57.27,55.49
    >>Talk to |cRXP_FRIENDLY_Eleanor Shackleton|r
    .accept 96607 >>Accept The Great Outdoors
    .target Eleanor Shackleton
step
    #completewith next
    .goto Tirisfal Glades,57.23,55.51
    +|cRXP_WARN_Type /sit at the campfire and wait one minute until you get the "Camp Benefits" buff|r
step
    .goto Tirisfal Glades,57.27,55.49
    >>Talk to |cRXP_FRIENDLY_Eleanor Shackleton|r
    .turnin 96607 >>Turn in The Great Outdoors
    .target Eleanor Shackleton
step
    #completewith GordoLoop
    #label GordoWatch
    >>|cRXP_WARN_Watch for|r |cRXP_FRIENDLY_Gordo|r|cRXP_WARN_, a big abomination that walks the road past|r |cRXP_FRIENDLY_Deathguard Lizabetha|r|cRXP_WARN_. Talk to him to get him to stand still, then select "I need a report for Executor Zygand"|r
    .complete 99141,3 --Gordo's Report
    .accept 5481 >>|cRXP_WARN_Once you're level 5, talk to him again and accept|r Gordo's Task
    .target Gordo
step
    #sticky
    #requires GordoWatch
    >>Loot |cRXP_PICK_Gloom Weed|r on the ground along the road west of Brill
    .complete 5481,1 --Gloom Weed (3)
step
    #label Claws
    .goto Tirisfal Glades,52.50,54.50
    >>Kill |cRXP_ENEMY_Rotting Dead|r and |cRXP_ENEMY_Ravaged Corpses|r near |cRXP_FRIENDLY_Deathguard Lizabetha|r on the road by Cold Hearth Manor. Loot them for |cRXP_LOOT_Putrid Claws|r
    >>|cRXP_WARN_Get each|r |cRXP_ENEMY_Ravaged Corpse|r |cRXP_WARN_to 50% health, then kite it back into|r |cRXP_FRIENDLY_Deathguard Lizabetha|r|cRXP_WARN_. She helps kill it, so it dies faster and you lose less health|r
    .complete 404,1 --Putrid Claw (7)
    .mob Rotting Dead
    .mob Ravaged Corpse
    .target Deathguard Lizabetha
step
    .goto Tirisfal Glades,52.50,54.50
    .xp 5 >>Grind to level 5 near Deathguard Lizabetha
    >>|cRXP_WARN_Keep kiting|r |cRXP_ENEMY_Ravaged Corpses|r |cRXP_WARN_into|r |cRXP_FRIENDLY_Deathguard Lizabetha|r |cRXP_WARN_at 50% health|r
    .mob Rotting Dead
    .mob Ravaged Corpse
step
    #label GordoLoop
    #loop
    .goto Tirisfal Glades,56.00,51.00,30,0
    .goto Tirisfal Glades,54.60,52.60,30,0
    .goto Tirisfal Glades,52.40,54.40,30,0
    .goto Tirisfal Glades,50.60,57.40,30,0
    .goto Tirisfal Glades,47.40,57.60,30,0
    .goto Tirisfal Glades,44.60,55.40,30,0
    .goto Tirisfal Glades,42.40,55.00,30,0
    .goto Tirisfal Glades,40.80,54.40,30,0
    >>|cRXP_WARN_If you haven't yet:|r find |cRXP_FRIENDLY_Gordo|r, an abomination that walks the road from Brill out to western Tirisfal
    >>|cRXP_WARN_Talk to him to get him to stand still. Select "I need a report for Executor Zygand", then accept his quest|r
    .complete 99141,3 --Gordo's Report
    .accept 5481 >>Accept Gordo's Task
    .target Gordo
step
    .isQuestComplete 86784
    .goto Tirisfal Glades,57.27,55.49
    >>Talk to |cRXP_FRIENDLY_Eleanor Shackleton|r at the campfire
    .turnin 86784 >>Turn in Sticks and Bones
    .target Eleanor Shackleton
step
    .goto Tirisfal Glades,58.20,51.45
    >>Talk to |cRXP_FRIENDLY_Deathguard Dillinger|r
    >>|cRXP_WARN_Select "I need a report for Executor Zygand"|r
    .turnin 404 >>Turn in A Putrid Task
    .complete 99141,1 --Dillinger's Report
    .target Deathguard Dillinger
step
    .goto Tirisfal Glades,60.56,51.76
    >>Talk to |cRXP_FRIENDLY_Executor Zygand|r
    .turnin 99141 >>Turn in Patience
    .accept 427 >>Accept At War With The Scarlet Crusade
    .target Executor Zygand
step
    >>Talk to |cRXP_FRIENDLY_Deathguard Burgess|r and |cRXP_FRIENDLY_Magistrate Sevren|r inside the town hall
    .accept 374 >>Accept Proof of Demise
    .target +Deathguard Burgess
    .goto Tirisfal Glades,60.93,52.01
    .accept 358 >>Accept Graverobbers
    .target +Magistrate Sevren
    .goto Tirisfal Glades,61.26,50.84
step
    #loop
    .goto Tirisfal Glades,57.50,52.50,0
    .goto Tirisfal Glades,57.50,52.50,40,0
    .goto Tirisfal Glades,60.00,55.00,40,0
    .goto Tirisfal Glades,60.00,57.50,40,0
    .goto Tirisfal Glades,62.50,55.00,40,0
    .goto Tirisfal Glades,57.50,55.00,40,0
    .goto Tirisfal Glades,55.00,52.50,40,0
    .xp 6 >>Grind to level 6
    >>Kill the |cRXP_ENEMY_Decrepit Darkhounds|r and |cRXP_ENEMY_Greater Duskbats|r just south of Brill. They're level 5-6
    .mob Decrepit Darkhound
    .mob Greater Duskbat
step
    .goto Tirisfal Glades,58.20,51.45
    >>Talk to |cRXP_FRIENDLY_Deathguard Dillinger|r
    .accept 426 >>Accept The Mills Overrun
    .target Deathguard Dillinger
step
    .goto Tirisfal Glades,59.45,52.40
    >>Talk to |cRXP_FRIENDLY_Apothecary Johaan|r
    .accept 367 >>Accept A New Plague
    .target Apothecary Johaan
step
    .goto Tirisfal Glades,60.23,52.67
    >>Talk to |cRXP_FRIENDLY_Shari Stilwell|r before you head west
    .trainer >>Train your level 6 class spells
    .target Shari Stilwell
step
    .isQuestComplete 86784
    .goto Tirisfal Glades,57.27,55.49
    >>Talk to |cRXP_FRIENDLY_Eleanor Shackleton|r at the campfire
    .turnin 86784 >>Turn in Sticks and Bones
    .target Eleanor Shackleton
step
    .goto Tirisfal Glades,40.91,54.17
    >>Travel west along the road. Talk to |cRXP_FRIENDLY_Deathguard Simmer|r
    .accept 365 >>Accept Fields of Grief
    .target Deathguard Simmer
step
    #completewith DarkhoundsWest
    >>Kill |cRXP_ENEMY_Decrepit Darkhounds|r along the road. Loot them for |cRXP_LOOT_Darkhound Blood|r
    .complete 367,1 --Darkhound Blood (5)
    .mob Decrepit Darkhound
step
    #loop
    .goto Tirisfal Glades,39.55,50.64,0
    .goto Tirisfal Glades,44.43,57.33,0
    .goto Tirisfal Glades,39.55,50.64,50,0
    .goto Tirisfal Glades,44.43,57.33,50,0
    >>Finish looting |cRXP_PICK_Gloom Weed|r on the ground along the road
    .complete 5481,1 --Gloom Weed (3)
step
    #completewith Tescort
    >>Kill |cRXP_ENEMY_Scarlet Warriors|r. Loot them for |cRXP_LOOT_Scarlet Insignia Rings|r
    .complete 427,1 --Scarlet Warrior (10)
    .complete 374,1 --Scarlet Insignia Ring (10)
    .mob Scarlet Warrior
step
    #loop
    .goto Tirisfal Glades,36.63,50.09,0
    .goto Tirisfal Glades,37.20,52.17,50,0
    .goto Tirisfal Glades,36.64,50.09,50,0
    .goto Tirisfal Glades,36.10,49.07,50,0
    .goto Tirisfal Glades,35.08,49.82,50,0
    .goto Tirisfal Glades,35.30,50.91,50,0
    .goto Tirisfal Glades,34.57,51.58,50,0
    .goto Tirisfal Glades,36.63,50.09,50,0
    >>Loot the |cRXP_PICK_Tirisfal Pumpkins|r in the field
    .complete 365,1 --Tirisfal Pumpkin (10)
step
    .goto Tirisfal Glades,31.99,46.40
    >>Talk to |cRXP_FRIENDLY_Bareth Dawnstone|r at the top of the tower. This starts an escort
    >>|cRXP_WARN_Be careful: at the top of the tower you can pull 3|r |cRXP_ENEMY_Scarlet Warriors|r |cRXP_WARN_at once|r
    .accept 99144 >>Accept Seeking Refuge
    .target Bareth Dawnstone
step
    #label Tescort
    .goto Tirisfal Glades,39.07,48.77
    >>Escort |cRXP_FRIENDLY_Bareth Dawnstone|r out of Solliden Farmstead
    .complete 99144,1 --Escort Bareth Dawnstone
    .target Bareth Dawnstone
step
    #loop
    .goto Tirisfal Glades,31.78,51.36,0
    .goto Tirisfal Glades,33.73,49.34,50,0
    .goto Tirisfal Glades,33.65,51.07,50,0
    .goto Tirisfal Glades,31.78,51.36,50,0
    .goto Tirisfal Glades,30.02,50.48,50,0
    .goto Tirisfal Glades,29.91,49.24,50,0
    .goto Tirisfal Glades,30.62,47.53,50,0
    .goto Tirisfal Glades,31.01,46.50,50,0
    .goto Tirisfal Glades,32.15,44.83,50,0
    .goto Tirisfal Glades,33.73,45.29,50,0
    .goto Tirisfal Glades,34.10,47.88,50,0
    .goto Tirisfal Glades,33.73,49.34,50,0
    >>Finish killing |cRXP_ENEMY_Scarlet Warriors|r. Keep any |cRXP_LOOT_Scarlet Insignia Rings|r they drop
    .complete 427,1 --Scarlet Warrior (10)
    .mob Scarlet Warrior
step
    #label DarkhoundsWest
    #loop
    .goto Tirisfal Glades,39.72,46.89,0
    .goto Tirisfal Glades,39.72,46.89,60,0
    .goto Tirisfal Glades,40.47,42.97,60,0
    .goto Tirisfal Glades,42.28,47.82,60,0
    .goto Tirisfal Glades,43.50,53.00,60,0
    >>Finish killing |cRXP_ENEMY_Decrepit Darkhounds|r for |cRXP_LOOT_Darkhound Blood|r
    .complete 367,1 --Darkhound Blood (5)
    .mob Decrepit Darkhound
step
    #completewith BrillTurnin1
    .deathskip >>Die and respawn at the |cRXP_FRIENDLY_Spirit Healer|r in Brill
step
    #label BrillTurnin1
    #loop
    .goto Tirisfal Glades,57.71,48.96,0
    .goto Tirisfal Glades,58.29,49.80,30,0
    .goto Tirisfal Glades,57.71,48.96,30,0
    .goto Tirisfal Glades,59.26,46.73,30,0
    >>Talk to |cRXP_FRIENDLY_Junior Apothecary Holland|r
    >>|cRXP_WARN_He patrols around the Brill graveyard|r
    .turnin 5481 >>Turn in Gordo's Task
    .accept 5482 >>Accept Doom Weed
    .target Junior Apothecary Holland
step
    .goto Tirisfal Glades,59.45,52.40
    >>Talk to |cRXP_FRIENDLY_Apothecary Johaan|r
    .turnin 365 >>Turn in Fields of Grief
    .accept 407 >>Accept Fields of Grief
    .turnin 367 >>Turn in A New Plague
    .accept 368 >>Accept A New Plague
    .target Apothecary Johaan
step
    >>Talk to |cRXP_FRIENDLY_Executor Zygand|r, then click the |cRXP_PICK_Wanted Poster|r and talk to |cRXP_FRIENDLY_Magistrate Sevren|r
    .turnin 427 >>Turn in At War With The Scarlet Crusade
    .accept 370 >>Accept At War With The Scarlet Crusade
    .target +Executor Zygand
    .goto Tirisfal Glades,60.56,51.76
    .accept 398 >>Accept Wanted: Maggot Eye
    .goto Tirisfal Glades,60.74,51.52
    .accept 359 >>Accept Forsaken Duties
    .target +Magistrate Sevren
    .goto Tirisfal Glades,61.26,50.84
step
    .goto Tirisfal Glades,60.23,52.67
    >>Talk to |cRXP_FRIENDLY_Shari Stilwell|r
    .turnin 99144 >>Turn in Seeking Refuge
    .target Shari Stilwell
step
    >>Talk to |cRXP_FRIENDLY_Shelene Rhobart|r and |cRXP_FRIENDLY_Deathguard Linnea|r south-east of Brill
    .accept 97558 >>Accept Hides for the Forsaken
    .target +Shelene Rhobart
    .goto Tirisfal Glades,65.42,60.11
    .turnin 359 >>Turn in Forsaken Duties
    .accept 360 >>Accept Return to the Magistrate
    .accept 356 >>Accept Rear Guard Patrol
    .target +Deathguard Linnea
    .goto Tirisfal Glades,65.49,60.25
step
    #completewith Doomweed
    >>Kill |cRXP_ENEMY_Decrepit Darkhounds|r. Loot them for |cRXP_LOOT_Darkhound Hides|r
    .complete 97558,2 --Darkhound Hide (6)
    .mob Decrepit Darkhound
step
    #completewith next
    >>Loot |cRXP_PICK_Doom Weed|r near the trees in the gnoll area
    .complete 5482,1 --Doom Weed (10)
step
    #loop
    .goto Tirisfal Glades,55.24,42.54,0
    .goto Tirisfal Glades,56.31,39.67,40,0
    .goto Tirisfal Glades,54.71,41.19,40,0
    .goto Tirisfal Glades,53.90,43.93,40,0
    .goto Tirisfal Glades,55.24,42.54,40,0
    .goto Tirisfal Glades,56.43,43.92,40,0
    >>Kill |cRXP_ENEMY_Rot Hide Graverobbers|r. Loot them for |cRXP_LOOT_Embalming Ichor|r
    .complete 358,1 --Rot Hide Graverobber (8)
    .complete 358,3 --Embalming Ichor (8)
    .mob Rot Hide Graverobber
step
    #completewith MaggotEye
    >>Kill |cRXP_ENEMY_Rot Hide Mongrels|r. Loot them for |cRXP_LOOT_Embalming Ichor|r
    .complete 358,2 --Rot Hide Mongrel (5)
    .complete 358,3 --Embalming Ichor (8)
    .mob Rot Hide Mongrel
step
    #label Doomweed
    #loop
    .goto Tirisfal Glades,57.48,35.95,0
    .goto Tirisfal Glades,57.68,34.37,30,0
    .goto Tirisfal Glades,57.45,35.96,30,0
    .goto Tirisfal Glades,56.79,37.79,30,0
    .goto Tirisfal Glades,56.05,38.76,30,0
    .goto Tirisfal Glades,55.09,38.74,30,0
    .goto Tirisfal Glades,55.25,40.16,30,0
    .goto Tirisfal Glades,54.68,42.12,30,0
    .goto Tirisfal Glades,55.29,41.51,30,0
    .goto Tirisfal Glades,56.58,41.99,30,0
    .goto Tirisfal Glades,58.29,42.93,30,0
    .goto Tirisfal Glades,58.83,40.68,30,0
    .goto Tirisfal Glades,58.36,38.55,30,0
    .goto Tirisfal Glades,57.48,35.95,30,0
    >>Loot |cRXP_PICK_Doom Weed|r near the trees in the gnoll area
    .complete 5482,1 --Doom Weed (10)
step
    #label MaggotEye
    .goto Tirisfal Glades,58.66,30.77
    >>Kill |cRXP_ENEMY_Maggot Eye|r. Loot him for |cRXP_LOOT_Maggot Eye's Paw|r
    >>|cRXP_WARN_He's level 10. Clear the gnolls around him first and start at full health|r
    .complete 398,1 --Maggot Eye's Paw (1)
    .mob Maggot Eye
step
    #loop
    .goto Tirisfal Glades,59.77,32.37,0
    .goto Tirisfal Glades,58.71,35.47,50,0
    .goto Tirisfal Glades,59.77,32.37,50,0
    .goto Tirisfal Glades,58.25,31.28,50,0
    .goto Tirisfal Glades,60.08,37.88,50,0
    >>Finish killing |cRXP_ENEMY_Rot Hide Mongrels|r and looting |cRXP_LOOT_Embalming Ichor|r from the gnolls
    .complete 358,2 --Rot Hide Mongrel (5)
    .complete 358,3 --Embalming Ichor (8)
    .mob Rot Hide Mongrel
    .mob Rot Hide Gnoll
    .mob Rot Hide Graverobber
step
    #loop
    .goto Tirisfal Glades,59.54,27.86,0
    .goto Tirisfal Glades,59.38,29.05,50,0
    .goto Tirisfal Glades,59.54,27.86,50,0
    .goto Tirisfal Glades,60.64,28.66,50,0
    .goto Tirisfal Glades,61.49,29.40,50,0
    .goto Tirisfal Glades,62.96,29.46,50,0
    .goto Tirisfal Glades,65.68,30.22,50,0
    .goto Tirisfal Glades,67.48,28.97,50,0
    .goto Tirisfal Glades,68.22,26.46,50,0
    >>Kill |cRXP_ENEMY_Vile Fin Murlocs|r along the lake shore. Loot them for |cRXP_LOOT_Vile Fin Scales|r and |cRXP_LOOT_Vile Fin Murloc Skins|r
    >>|cRXP_ENEMY_Vile Fin Puddlejumpers|r |cRXP_WARN_do NOT drop the skins|r
    .complete 368,1 --Vile Fin Scale (5)
    .complete 97558,3 --Vile Fin Murloc Skin (3)
    .mob Vile Fin Puddlejumper
    .mob Vile Fin Minor Oracle
    .mob Vile Fin Muckdweller
step
    #loop
    .goto Tirisfal Glades,64.07,33.46,0
    .goto Tirisfal Glades,64.07,33.46,50,0
    .goto Tirisfal Glades,64.45,36.85,50,0
    .goto Tirisfal Glades,64.31,41.02,50,0
    .goto Tirisfal Glades,62.45,42.89,50,0
    .goto Tirisfal Glades,63.89,47.45,50,0
    .goto Tirisfal Glades,65.03,50.64,50,0
    .goto Tirisfal Glades,66.24,52.76,50,0
    .goto Tirisfal Glades,70.16,54.16,50,0
    .goto Tirisfal Glades,71.35,48.13,50,0
    >>Kill |cRXP_ENEMY_Duskbats|r on the way back toward Brill. Loot them for |cRXP_LOOT_Duskbat Wing Membranes|r
    .complete 97558,1 --Duskbat Wing Membrane (8)
    .mob Greater Duskbat
    .mob Vampiric Duskbat
step
    #loop
    .goto Tirisfal Glades,65.00,50.50,0
    .goto Tirisfal Glades,65.00,50.50,40,0
    .goto Tirisfal Glades,67.50,53.50,40,0
    .goto Tirisfal Glades,62.50,46.50,40,0
    >>Finish killing |cRXP_ENEMY_Decrepit Darkhounds|r for |cRXP_LOOT_Darkhound Hides|r
    .complete 97558,2 --Darkhound Hide (6)
    .mob Decrepit Darkhound
step
    >>Talk to |cRXP_FRIENDLY_Gretchen Dedmar|r upstairs in the inn and |cRXP_FRIENDLY_Coleman Farthing|r downstairs
    .accept 375 >>Accept The Chill of Death
    .target +Gretchen Dedmar
    .goto Tirisfal Glades,61.89,52.73
    .accept 354 >>Accept Deaths in the Family
    .accept 362 >>Accept The Haunted Mills
    .target +Coleman Farthing
    .goto Tirisfal Glades,61.72,52.29
step
    .goto Tirisfal Glades,61.03,52.35
    >>Talk to |cRXP_FRIENDLY_Abigail Shiel|r
    >>|cRXP_BUY_Buy a|r |T132891:0|t[Coarse Thread] |cRXP_BUY_and sell your junk|r
    .complete 375,2 --Coarse Thread (1)
    .target Abigail Shiel
step
    >>Talk to |cRXP_FRIENDLY_Magistrate Sevren|r and |cRXP_FRIENDLY_Executor Zygand|r in the town hall
    .turnin 358 >>Turn in Graverobbers
    .turnin 360 >>Turn in Return to the Magistrate
    .target +Magistrate Sevren
    .goto Tirisfal Glades,61.26,50.84
    .turnin 398 >>Turn in Wanted: Maggot Eye
    .target +Executor Zygand
    .goto Tirisfal Glades,60.56,51.76
step
    .goto Tirisfal Glades,60.23,52.67
    .xp <8,1
    >>Talk to |cRXP_FRIENDLY_Shari Stilwell|r
    .trainer >>Train your level 8 class spells
    .target Shari Stilwell
step
    >>Talk to |cRXP_FRIENDLY_Apothecary Johaan|r and |cRXP_FRIENDLY_Carolai Anise|r
    .turnin 368 >>Turn in A New Plague
    .accept 369 >>Accept A New Plague
    .target +Apothecary Johaan
    .goto Tirisfal Glades,59.45,52.40
    .accept 95314 >>Accept That Shadowvale Green Elixir
    .target +Carolai Anise
    .goto Tirisfal Glades,59.44,52.20
step
    #loop
    .goto Tirisfal Glades,57.71,48.96,0
    .goto Tirisfal Glades,58.29,49.80,30,0
    .goto Tirisfal Glades,57.71,48.96,30,0
    .goto Tirisfal Glades,59.26,46.73,30,0
    >>Talk to |cRXP_FRIENDLY_Junior Apothecary Holland|r
    >>|cRXP_WARN_He patrols around the Brill graveyard|r
    .turnin 5482 >>Turn in Doom Weed
    .accept 99142 >>Accept Tomb Weed
    .target Junior Apothecary Holland
step
    .isQuestComplete 86784
    .goto Tirisfal Glades,57.27,55.49
    >>Talk to |cRXP_FRIENDLY_Eleanor Shackleton|r at the campfire
    .turnin 86784 >>Turn in Sticks and Bones
    .target Eleanor Shackleton
step
    #completewith ScarletCamp
    >>Kill |cRXP_ENEMY_Duskbats|r on the way south. Loot them for |cRXP_LOOT_Duskbat Pelts|r
    .complete 375,1 --Duskbat Pelt (5)
    .mob Greater Duskbat
    .mob Vampiric Duskbat
step
    #label ScarletCamp
    #loop
    .goto Tirisfal Glades,50.07,68.87,40,0
    .goto Tirisfal Glades,50.23,66.94,40,0
    .goto Tirisfal Glades,51.16,65.73,40,0
    .goto Tirisfal Glades,51.75,66.04,40,0
    .goto Tirisfal Glades,52.93,67.62,40,0
    .goto Tirisfal Glades,52.72,69.33,40,0
    .goto Tirisfal Glades,51.96,69.57,40,0
    .goto Tirisfal Glades,51.03,69.55,40,0
    >>Kill |cRXP_ENEMY_Captain Perrine|r, |cRXP_ENEMY_Scarlet Zealots|r and |cRXP_ENEMY_Scarlet Missionaries|r. Loot them for |cRXP_LOOT_Scarlet Insignia Rings|r
    .complete 370,1 --Captain Perrine (1)
    .mob +Captain Perrine
    .complete 370,2 --Scarlet Zealot (3)
    .mob +Scarlet Zealot
    .complete 370,3 --Scarlet Missionary (3)
    .mob +Scarlet Missionary
    .complete 374,1 --Scarlet Insignia Ring (10)
    .disablecheckbox
step
    #loop
    .goto Tirisfal Glades,55.00,60.00,0
    .goto Tirisfal Glades,52.50,61.00,40,0
    .goto Tirisfal Glades,55.00,60.00,40,0
    .goto Tirisfal Glades,57.50,57.50,40,0
    .goto Tirisfal Glades,60.00,56.00,40,0
    >>Finish killing |cRXP_ENEMY_Duskbats|r for |cRXP_LOOT_Duskbat Pelts|r on the way back to Brill
    .complete 375,1 --Duskbat Pelt (5)
    .mob Greater Duskbat
    .mob Vampiric Duskbat
step
    .goto Tirisfal Glades,60.56,51.76
    >>Talk to |cRXP_FRIENDLY_Executor Zygand|r
    .turnin 370 >>Turn in At War With The Scarlet Crusade
    .accept 371 >>Accept At War With The Scarlet Crusade
    .target Executor Zygand
step
    .isQuestComplete 374
    .goto Tirisfal Glades,60.93,52.01
    >>Talk to |cRXP_FRIENDLY_Deathguard Burgess|r
    .turnin 374 >>Turn in Proof of Demise
    .target Deathguard Burgess
step
    .goto Tirisfal Glades,61.89,52.73
    >>Talk to |cRXP_FRIENDLY_Gretchen Dedmar|r upstairs in the inn
    .turnin 375 >>Turn in The Chill of Death
    .target Gretchen Dedmar
step
    .goto Tirisfal Glades,47.37,43.71,30 >>Travel north-west to Agamand Mills
    .isOnQuest 362
step
    #completewith ThurmanGregor
    >>|T134939:0|t[|cRXP_LOOT_A Letter to Yvette|r] |cRXP_WARN_can drop from the undead here. If it does, click it and accept the quest|r
    .collect 2839,1,361 --A Letter to Yvette (1)
    .accept 361 >>Accept A Letter Undelivered
    .use 2839
step
    #completewith MillsOverrun
    >>Kill |cRXP_ENEMY_Soldiers|r and |cRXP_ENEMY_Bonecasters|r. Loot them for |cRXP_LOOT_Notched Ribs|r and |cRXP_LOOT_Blackened Skulls|r
    .complete 426,1 --Notched Rib (5)
    .mob +Rattlecage Soldier
    .mob +Cracked Skull Soldier
    .complete 426,2 --Blackened Skull (3)
    .mob +Darkeye Bonecaster
step
    .goto Tirisfal Glades,47.34,40.78
    >>Kill |cRXP_ENEMY_Devlin Agamand|r. Loot him for |cRXP_LOOT_Devlin's Remains|r
    .complete 362,1 --Devlin's Remains (1)
    .mob Devlin Agamand
step
    .goto Tirisfal Glades,49.34,36.02
    >>Kill |cRXP_ENEMY_Nissa Agamand|r. Loot her for |cRXP_LOOT_Nissa's Remains|r. She can be inside the building
    .complete 354,2 --Nissa's Remains (1)
    .mob Nissa Agamand
step
    #label ThurmanGregor
    #loop
    .goto Tirisfal Glades,45.08,31.15,0
    .goto Tirisfal Glades,43.71,35.25,60,0
    .goto Tirisfal Glades,45.03,30.99,60,0
    .goto Tirisfal Glades,46.79,29.80,60,0
    .goto Tirisfal Glades,42.82,31.93,60,0
    .goto Tirisfal Glades,45.08,31.15,60,0
    >>Kill |cRXP_ENEMY_Thurman Agamand|r and |cRXP_ENEMY_Gregor Agamand|r. Loot them for their |cRXP_LOOT_Remains|r
    >>|cRXP_WARN_They can patrol around the mill|r
    .complete 354,3 --Thurman's Remains (1)
    .unitscan +Thurman Agamand
    .complete 354,1 --Gregor's Remains (1)
    .unitscan +Gregor Agamand
step
    #label MillsOverrun
    #loop
    .goto Tirisfal Glades,45.08,31.15,0
    .goto Tirisfal Glades,43.71,35.25,60,0
    .goto Tirisfal Glades,45.03,30.99,60,0
    .goto Tirisfal Glades,46.79,29.80,60,0
    .goto Tirisfal Glades,42.82,31.93,60,0
    .goto Tirisfal Glades,45.08,31.15,60,0
    >>Finish killing |cRXP_ENEMY_Soldiers|r and |cRXP_ENEMY_Bonecasters|r for |cRXP_LOOT_Notched Ribs|r and |cRXP_LOOT_Blackened Skulls|r
    .complete 426,1 --Notched Rib (5)
    .mob +Rattlecage Soldier
    .mob +Cracked Skull Soldier
    .complete 426,2 --Blackened Skull (3)
    .mob +Darkeye Bonecaster
step
    #completewith Mills
    .deathskip >>Die and respawn at the |cRXP_FRIENDLY_Spirit Healer|r in Brill
step
    #label Mills
    .goto Tirisfal Glades,58.20,51.45
    >>Talk to |cRXP_FRIENDLY_Deathguard Dillinger|r
    .turnin 426 >>Turn in The Mills Overrun
    .target Deathguard Dillinger
step
    .isOnQuest 361
    .goto Tirisfal Glades,61.58,52.60
    >>Talk to |cRXP_FRIENDLY_Yvette Farthing|r in the inn
    .turnin 361 >>Turn in A Letter Undelivered
    .target Yvette Farthing
step
    .goto Tirisfal Glades,61.72,52.29
    >>Talk to |cRXP_FRIENDLY_Coleman Farthing|r in the inn
    .turnin 354 >>Turn in Deaths in the Family
    .turnin 362 >>Turn in The Haunted Mills
    .accept 355 >>Accept Speak with Sevren
    .target Coleman Farthing
step
    .goto Tirisfal Glades,61.26,50.84
    >>Talk to |cRXP_FRIENDLY_Magistrate Sevren|r
    .turnin 355 >>Turn in Speak with Sevren
    .target Magistrate Sevren
step
    #completewith Linen
    >>|cRXP_WARN_Keep at least 10|r |T132889:0|t[Linen Cloth]|cRXP_WARN_. Don't sell it. A Paladin quest in the Undercity needs it|r
    .collect 2589,10 --Linen Cloth (10)
step
    .goto Tirisfal Glades,65.42,60.11
    >>Head east. On the way, talk to |cRXP_FRIENDLY_Shelene Rhobart|r
    .turnin 97558 >>Turn in Hides for the Forsaken
    .target Shelene Rhobart
step
    #completewith HorrorsAndSpirits
    .goto Tirisfal Glades,76.51,61.77,60 >>Travel east to Balnir Farmstead
step
    #completewith HorrorsAndSpirits
    >>Loot the |cRXP_PICK_Tomb Weed|r on the ground
    .complete 99142,1 --Tomb Weed (5)
step
    #label HorrorsAndSpirits
    #loop
    .goto Tirisfal Glades,74.31,60.98,0
    .goto Tirisfal Glades,74.31,60.98,50,0
    .goto Tirisfal Glades,74.45,59.64,50,0
    .goto Tirisfal Glades,75.08,58.56,50,0
    .goto Tirisfal Glades,76.45,58.67,50,0
    .goto Tirisfal Glades,77.41,58.66,50,0
    .goto Tirisfal Glades,78.55,60.43,50,0
    .goto Tirisfal Glades,77.45,61.46,50,0
    .goto Tirisfal Glades,76.79,62.60,50,0
    .goto Tirisfal Glades,74.99,61.98,50,0
    >>Kill |cRXP_ENEMY_Bleeding Horrors|r and |cRXP_ENEMY_Wandering Spirits|r
    .complete 356,1 --Bleeding Horror (8)
    .mob +Bleeding Horror
    .complete 356,2 --Wandering Spirit (8)
    .mob +Wandering Spirit
step
    .goto Tirisfal Glades,74.98,59.37
    >>Finish looting the |cRXP_PICK_Tomb Weed|r on the ground
    .complete 99142,1 --Tomb Weed (5)
step
    #completewith Vachon
    >>Kill |cRXP_ENEMY_Scarlet Friars|r
    .complete 371,2 --Scarlet Friar (5)
    .mob Scarlet Friar
step
    #label Vachon
    .goto Tirisfal Glades,78.82,56.14
    >>Kill |cRXP_ENEMY_Captain Vachon|r inside the tower
    .complete 371,1 --Captain Vachon (1)
    .mob Captain Vachon
step
    #loop
    .goto Tirisfal Glades,80.95,57.21,0
    .goto Tirisfal Glades,77.14,54.92,0
    .goto Tirisfal Glades,80.95,57.21,40,0
    .goto Tirisfal Glades,81.62,54.84,40,0
    .goto Tirisfal Glades,81.56,53.07,40,0
    .goto Tirisfal Glades,79.31,55.25,40,0
    .goto Tirisfal Glades,77.14,54.92,40,0
    .goto Tirisfal Glades,76.15,55.30,40,0
    .goto Tirisfal Glades,76.12,57.22,40,0
    .goto Tirisfal Glades,77.16,56.75,40,0
    .goto Tirisfal Glades,79.82,56.40,40,0
    >>Finish killing |cRXP_ENEMY_Scarlet Friars|r. Also loot |cRXP_LOOT_Scarlet Insignia Rings|r if you still need them
    .complete 371,2 --Scarlet Friar (5)
    .mob Scarlet Friar
    .complete 374,1 --Scarlet Insignia Ring (10)
    .disablecheckbox
step
    #loop
    .goto Tirisfal Glades,85.03,54.72,0
    .goto Tirisfal Glades,83.50,55.56,30,0
    .goto Tirisfal Glades,85.03,54.72,30,0
    .goto Tirisfal Glades,86.56,54.51,30,0
    .goto Tirisfal Glades,88.06,54.99,30,0
    .goto Tirisfal Glades,88.94,53.56,30,0
    .goto Tirisfal Glades,89.70,51.88,30,0
    .goto Tirisfal Glades,90.92,50.56,30,0
    .goto Tirisfal Glades,90.87,48.33,30,0
    .goto Tirisfal Glades,89.87,46.65,30,0
    .goto Tirisfal Glades,85.04,46.68,30,0
    .goto Tirisfal Glades,84.52,49.29,30,0
    .goto Tirisfal Glades,83.46,52.09,30,0
    >>Kill |cRXP_ENEMY_Vicious Night Web Spiders|r. Loot them for |cRXP_LOOT_Vicious Night Web Spider Venom|r
    .complete 369,1 --Vicious Night Web Spider Venom (4)
    .mob Vicious Night Web Spider
step
    .goto Tirisfal Glades,85.03,54.72
    .xp 10 >>Keep killing spiders until you're level 10
    .mob Vicious Night Web Spider
step
    #completewith BrillTurnin6
    .goto Tirisfal Glades,66.60,44.95
    .deathskip >>Die |cRXP_WARN_on the smaller island|r and respawn at the |cRXP_FRIENDLY_Spirit Healer|r in Brill
step
    #label BrillTurnin6
    #loop
    .goto Tirisfal Glades,57.71,48.96,0
    .goto Tirisfal Glades,58.29,49.80,30,0
    .goto Tirisfal Glades,57.71,48.96,30,0
    .goto Tirisfal Glades,59.26,46.73,30,0
    >>Talk to |cRXP_FRIENDLY_Junior Apothecary Holland|r
    >>|cRXP_WARN_He patrols around the Brill graveyard|r
    .turnin 99142 >>Turn in Tomb Weed
    .target Junior Apothecary Holland
step
    .goto Tirisfal Glades,59.45,52.40
    >>Talk to |cRXP_FRIENDLY_Apothecary Johaan|r
    .turnin 369 >>Turn in A New Plague
    .accept 492 >>Accept A New Plague
    .accept 445 >>Accept Delivery to Silverpine Forest
    .target Apothecary Johaan
step
    .goto Tirisfal Glades,60.23,52.67
    >>Talk to |cRXP_FRIENDLY_Shari Stilwell|r
    >>|cRXP_WARN_If she doesn't offer A Second Home, train and then skip this step|r
    .trainer >>Train your class spells
    .accept 91282 >>Accept A Second Home
    .target Shari Stilwell
step
    .goto Tirisfal Glades,60.56,51.76
    >>Talk to |cRXP_FRIENDLY_Executor Zygand|r
    .turnin 371 >>Turn in At War With The Scarlet Crusade
    .target Executor Zygand
step
    .isQuestComplete 374
    .goto Tirisfal Glades,60.93,52.01
    >>Talk to |cRXP_FRIENDLY_Deathguard Burgess|r
    .turnin 374 >>Turn in Proof of Demise
    .target Deathguard Burgess
step
    .goto Tirisfal Glades,61.71,52.06
    >>Talk to |cRXP_FRIENDLY_Innkeeper Renee|r
    .vendor 5688 >>Sell your junk and restock food
    .target Innkeeper Renee
step
    >>Go downstairs in the back of the inn. Talk to the |cRXP_FRIENDLY_Captured Scarlet Zealot|r and the |cRXP_FRIENDLY_Captured Mountaineer|r
    .turnin 407 >>Turn in Fields of Grief
    .target +Captured Scarlet Zealot
    .goto Tirisfal Glades,61.97,51.29
    .turnin 492 >>Turn in A New Plague
    .target +Captured Mountaineer
    .goto Tirisfal Glades,61.94,51.40
step
    .goto Tirisfal Glades,61.49,53.50
    >>Talk to |cRXP_FRIENDLY_Deathguard Terrence|r outside the inn
    .accept 96895 >>Accept The Argent Emissary
    .target Deathguard Terrence
step
    >>Talk to |cRXP_FRIENDLY_Deathguard Linnea|r and |cRXP_FRIENDLY_Hadric Harlson|r south-east of Brill
    .turnin 356 >>Turn in Rear Guard Patrol
    .target +Deathguard Linnea
    .goto Tirisfal Glades,65.49,60.25
    .turnin 96895 >>Turn in The Argent Emissary
    .accept 96897 >>Accept The Cult of the Damned
    .accept 96898 >>Accept Remnants of War
    .target +Hadric Harlson
    .goto Tirisfal Glades,65.92,61.11
step
    .goto Tirisfal Glades,70.02,64.06
    >>Kill |cRXP_ENEMY_Dark Enforcers|r and |cRXP_ENEMY_Dark Neophytes|r. Loot them for |cRXP_LOOT_Necrotic Crystal Fragments|r
    >>|cRXP_LOOT_Necrotic Crystal Fragments|r |cRXP_WARN_can also be looted from the ground|r
    >>|cRXP_WARN_Careful: these hit hard, and|r |cRXP_ENEMY_Dark Enforcers|r |cRXP_WARN_have an instant 50-70 damage ability|r
    .complete 96897,2 --Dark Enforcer slain (8)
    .mob +Dark Enforcer
    .complete 96897,1 --Dark Neophyte slain (8)
    .mob +Dark Neophyte
    .complete 96898,1 --Necrotic Crystal Fragment (12)
step
    .goto Tirisfal Glades,65.92,61.11
    >>Talk to |cRXP_FRIENDLY_Hadric Harlson|r
    .turnin 96897 >>Turn in The Cult of the Damned
    .turnin 96898 >>Turn in Remnants of War
    .accept 96899 >>Accept Bandarion Keep
    .target Hadric Harlson
step
    #completewith next
    .goto Tirisfal Glades,28.79,46.46,50,0
    .goto Tirisfal Glades,26.53,46.92,50,0
    .goto Tirisfal Glades,23.68,49.69,50,0
    .goto Tirisfal Glades,21.96,49.29,50,0
    .goto Tirisfal Glades,21.76,45.62,50 >>Travel west to Bandarion Keep
step
    .goto Tirisfal Glades,21.85,45.21
    >>Talk to |cRXP_FRIENDLY_Breton Samuels|r
    .turnin 91282 >>Turn in A Second Home
    .accept 91285 >>Accept Murlocs at the Gates
    .target Breton Samuels
step
    .goto Tirisfal Glades,22.03,44.73
    >>Talk to |cRXP_FRIENDLY_Leonid Barthalomew the Revered|r upstairs
    .turnin 96899 >>Turn in Bandarion Keep
    .accept 96896 >>Accept A Righteous Cause
    .target Leonid Barthalomew the Revered
step
    .goto Tirisfal Glades,22.03,44.73
    >>Talk to |cRXP_FRIENDLY_Leonid Barthalomew the Revered|r again
    .turnin 96896 >>Turn in A Righteous Cause
    .accept 98545 >>Accept Leonid's Letter
    .target Leonid Barthalomew the Revered
step
    >>Talk to |cRXP_FRIENDLY_Hilda the Breaker|r and |cRXP_FRIENDLY_Ephram Barbaro|r outside
    .accept 99152 >>Accept As Above, So Below
    .target +Hilda the Breaker
    .goto Tirisfal Glades,21.96,47.18
    .accept 99153 >>Accept The One That Got Away
    .target +Ephram Barbaro
    .goto Tirisfal Glades,20.17,46.50
step
    .goto Tirisfal Glades,17.13,58.12
    >>Kill |cRXP_ENEMY_Vile Fin Seers|r and |cRXP_ENEMY_Vile Fin Attackers|r
    .complete 91285,2 --Vile Fin Seer slain (8)
    .mob +Vile Fin Seer
    .complete 91285,1 --Vile Fin Attacker slain (8)
    .mob +Vile Fin Attacker
step
    .goto Tirisfal Glades,21.85,45.21
    >>Talk to |cRXP_FRIENDLY_Breton Samuels|r
    >>|cRXP_WARN_The weapon reward is a big upgrade|r
    .turnin 91285 >>Turn in Murlocs at the Gates
    .accept 91294 >>Accept Touring the Grounds
    .target Breton Samuels
step
    .goto Tirisfal Glades,22.01,47.19
    >>Talk to |cRXP_FRIENDLY_Hilda the Breaker|r
    .complete 91294,1 --Speak with Hilda the Breaker
    .target Hilda the Breaker
step
    .goto Tirisfal Glades,23.73,49.89
    >>Talk to |cRXP_FRIENDLY_Ander Solliden|r
    .complete 91294,3 --Speak with Ander Solliden
    .target Ander Solliden
step
    .goto Tirisfal Glades,22.69,44.69
    >>Talk to |cRXP_FRIENDLY_Jorin Croge|r
    .complete 91294,2 --Speak with Jorin Croge
    .target Jorin Croge
step
    .goto Tirisfal Glades,22.09,44.66
    >>Talk to |cRXP_FRIENDLY_Danitha Morr|r
    .complete 91294,4 --Speak with Danitha Morr
    .turnin 91294 >>Turn in Touring the Grounds
    .accept 91317 >>Accept The Tarnished
    .target Danitha Morr
step
    .goto Tirisfal Glades,22.70,44.68
    >>Talk to |cRXP_FRIENDLY_Jorin Croge|r
    .accept 91316 >>Accept Making Repairs
    .target Jorin Croge
step
    #completewith Tarnished
    >>Kill |cRXP_ENEMY_Tarnished Zealots|r and |cRXP_ENEMY_Tarnished Drudges|r
    .complete 91317,3 --Tarnished Zealot slain (6)
    .mob +Tarnished Zealot
    .complete 91317,2 --Tarnished Drudge slain (8)
    .mob +Tarnished Drudge
step
    .goto Tirisfal Glades,11.48,64.20
    >>Kill |cRXP_ENEMY_Rudolph Gelhardt|r upstairs. Loot him for |cRXP_LOOT_Rudolph Gelhardt's Head|r
    .complete 91317,1 --Rudolph Gelhardt's Head (1)
    .mob Rudolph Gelhardt
step
    #label Tarnished
    .goto Tirisfal Glades,12.07,63.98
    >>Finish killing |cRXP_ENEMY_Tarnished Zealots|r and |cRXP_ENEMY_Tarnished Drudges|r
    .complete 91317,3 --Tarnished Zealot slain (6)
    .mob +Tarnished Zealot
    .complete 91317,2 --Tarnished Drudge slain (8)
    .mob +Tarnished Drudge
step
    #label ShadowvaleCrypt
    .goto Tirisfal Glades,12.92,65.72,10 >>Enter the Shadowvale Crypt
step
    #completewith GlowingFragment
    >>Kill |cRXP_ENEMY_Shadowvale Lurchers|r and |cRXP_ENEMY_Shadowvale Mystics|r. Loot them for |cRXP_LOOT_Faintly Glowing Bones|r
    .complete 99152,1 --Faintly Glowing Bone (6)
    .mob Shadowvale Lurcher
    .mob Shadowvale Mystic
step
    #completewith GlowingBones
    >>Loot the |cRXP_PICK_Lumber Piles|r and |cRXP_PICK_Bottles of Whispering Elixir|r on the ground
    .complete 91316,1 --Sturdy Lumber (12)
    .complete 95314,1 --Bottle of Whispering Elixir (8)
step
    #label GlowingFragment
    .goto Tirisfal Glades,9.76,69.35
    >>Loot the |cRXP_PICK_Glowing Crystal Fragment|r on the ground
    .complete 99153,1 --Glowing Crystal Fragment (1)
step
    #label GlowingBones
    .goto Tirisfal Glades,10.56,65.35
    >>Finish killing |cRXP_ENEMY_Shadowvale Lurchers|r and |cRXP_ENEMY_Shadowvale Mystics|r for |cRXP_LOOT_Faintly Glowing Bones|r
    .complete 99152,1 --Faintly Glowing Bone (6)
    .mob Shadowvale Lurcher
    .mob Shadowvale Mystic
step
    .goto Tirisfal Glades,8.53,67.12
    >>Finish looting the |cRXP_PICK_Lumber Piles|r and |cRXP_PICK_Bottles of Whispering Elixir|r
    .complete 91316,1 --Sturdy Lumber (12)
    .complete 95314,1 --Bottle of Whispering Elixir (8)
step
    #completewith next
    .deathskip >>Die and respawn at the |cRXP_FRIENDLY_Spirit Healer|r near Bandarion Keep
step
    >>Talk to |cRXP_FRIENDLY_Hilda the Breaker|r and |cRXP_FRIENDLY_Ephram Barbaro|r
    .turnin 99152 >>Turn in As Above, So Below
    .target +Hilda the Breaker
    .goto Tirisfal Glades,22.05,47.16
    .turnin 99153 >>Turn in The One That Got Away
    .target +Ephram Barbaro
    .goto Tirisfal Glades,20.16,46.50
step
    .goto Tirisfal Glades,22.69,44.69
    >>Talk to |cRXP_FRIENDLY_Jorin Croge|r
    .turnin 91316 >>Turn in Making Repairs
    .target Jorin Croge
step
    .goto Tirisfal Glades,22.09,44.66
    >>Talk to |cRXP_FRIENDLY_Danitha Morr|r
    .turnin 91317 >>Turn in The Tarnished
    .accept 95803 >>Accept A Token of Good Faith
    .target Danitha Morr
step
    .xp <12,1
    .goto Tirisfal Glades,22.09,44.66
    >>Talk to |cRXP_FRIENDLY_Danitha Morr|r
    >>|cRXP_WARN_Needs level 12. This step skips itself if you're not 12 yet|r
    .accept 94427 >>Accept A Lesson in Divinity
    .target Danitha Morr
step
    #completewith Carolai
    .hs >>Hearth to Brill
step
    #label Carolai
    .goto Tirisfal Glades,59.44,52.20
    >>Talk to |cRXP_FRIENDLY_Carolai Anise|r
    .turnin 95314 >>Turn in That Shadowvale Green Elixir
    .target Carolai Anise
step
    #label Linen
    .goto Tirisfal Glades,61.92,64.85
    .zone Undercity >>Travel south to the Ruins of Lordaeron and take the lift down into the Undercity
step
    .isOnQuest 94427
    .goto Undercity,65.40,37.60
    >>Talk to |cRXP_FRIENDLY_Tanis Alderwood|r
    .turnin 94427 >>Turn in A Lesson in Divinity
    .accept 94434 >>Accept A Lesson in Divinity
    .turnin 94434 >>Turn in A Lesson in Divinity
    .accept 94435 >>Accept A Lesson in Divinity
    .target Tanis Alderwood
step
    .goto Undercity,67.40,38.40
    >>Talk to |cRXP_FRIENDLY_Innkeeper Norman|r
    .home >>Set your Hearthstone to the Undercity
    .target Innkeeper Norman
step
    .goto Undercity,69.60,46.90
    >>Talk to |cRXP_FRIENDLY_Glix Xizzix|r
    .turnin 98545 >>Turn in Leonid's Letter
    .target Glix Xizzix
step
    .goto Undercity,57.50,91.60
    >>Talk to |cRXP_FRIENDLY_Lady Sylvanas Windrunner|r in the Royal Quarter
    .turnin 95803 >>Turn in A Token of Good Faith
    .target Lady Sylvanas Windrunner
step
    .goto Tirisfal Glades,53.20,75.82
    .zone Silverpine Forest >>Leave the Undercity and travel south into Silverpine Forest
]])
